const data  = {
    byProdGrpData: [
        { name: 'FY14', compute: 245.657, vcan: 59.343, amt: 2400, dsktp: 345.44, mbl: 245.657, vsan: 454.4545, nsx: 345.44, mgmt: 34.343, others: 343.34 },
        { name: 'FY15', compute: 285.657, vcan: 55.343, amt: 2210, dsktp: 305.44, mbl: 345.44, vsan: 345.44, nsx: 343.3434, mgmt: 345.44, others: 345.44 },
        { name: 'FY16', compute: 205.657, vcan: 51.343, amt: 2290, dsktp: 385.44, mbl: 545.657, vsan: 454.4545, nsx: 345.44, mgmt: 345.44, others: 443.34 },
        { name: 'FY17', compute: 235.657, vcan: 57.343, amt: 2000, dsktp: 375.44, mbl: 149.657, vsan: 554.4545, nsx: 443.3434, mgmt: 345.44, others: 543.34 },
    ],
    byProdGrpbarBackgrnd: {
        data: [
            ["others", "#8377d9"],
            ["mgmt", "#8ee35f"],
            ["nsx", "#ffb7a8"],
            ["vsan", "#25ffc4"],
            ["mbl", "#ff8073"],
            ["dsktp", "#ffea63"],
            ["vcan", "#66c1ff"],
            ["compute", "#ffb1e8"],
        ]
    },
    byProdClassData: [
        { name: 'FY14', PSO: 45.657, SNS: 55.343, amt: "1K", Licence: 35.44, others: 43.34 },
        { name: 'FY15', PSO: 185.657, SNS: 55.343, amt: "2K", Licence: 35.44, others: 75.44 },
        { name: 'FY16', PSO: 50, SNS: 51.343, amt: "3K", Licence: 35.44, others: 43.34 },
        { name: 'FY17', PSO: 83.34, SNS: 0, amt: "4K", Licence: 0, others: 0 },
    ],
    byProdClassbarBackgrnd: {
        data: [
            ["others", "#8377d9"],
            ["Licence", "#25ffc4"],
            ["SNS", "#ffb1e8"],
            ["PSO", "#66c1ff"],
        ]
    },
    ELAtransPurchaseData: [
        { name: 'FY12', transaction: 500, ELA: 55.343, amt: "1K" },
        { name: 'FY13', transaction: 500, ELA: 550.343, amt: "2K" },
        { name: 'FY14', transaction: 50, ELA: 71.343, amt: "3K" },
        { name: 'FY15', transaction: 200, ELA: 0, amt: "4K" },
    ],
    ELAtransPurchaseBackgrnd: {
        data: [
            ["ELA", "#ff8073"],
            ["transaction", "#8377d9"],
        ]
    },
    futurePipelineData: [
        { name: "Q4'14", compute: 245.657, cloud: 59.343, amt: 2400, service: 55, dsktp: 345.44, mbl: 245.657, vsan: 454.4545, nsx: 345.44, mgmt: 34.343, others: 343.34 },
        { name: "Q4'15", compute: 285.657, cloud: 55.343, amt: 2210, service: 55, dsktp: 305.44, mbl: 345.44, vsan: 345.44, nsx: 343.3434, mgmt: 345.44, others: 345.44 },
        { name: "Q4'16", compute: 205.657, cloud: 51.343, amt: 2290, service: 55, dsktp: 385.44, mbl: 545.657, vsan: 454.4545, nsx: 345.44, mgmt: 345.44, others: 443.34 },
        { name: "Q4'17", compute: 235.657, cloud: 57.343, amt: 2000, service: 55, dsktp: 375.44, mbl: 149.657, vsan: 554.4545, nsx: 443.3434, mgmt: 345.44, others: 543.34 },
        { name: "Q4'18", compute: 245.657, cloud: 59.343, amt: 2400, service: 55, dsktp: 345.44, mbl: 245.657, vsan: 454.4545, nsx: 345.44, mgmt: 34.343, others: 343.34 },
        { name: "Q4'19", compute: 285.657, cloud: 55.343, amt: 2210, service: 55, dsktp: 305.44, mbl: 345.44, vsan: 345.44, nsx: 343.3434, mgmt: 345.44, others: 345.44 },
        { name: "Q4'20", compute: 205.657, cloud: 51.343, amt: 2290, service: 55, dsktp: 385.44, mbl: 545.657, vsan: 454.4545, nsx: 345.44, mgmt: 345.44, others: 443.34 },
        { name: "Q4'21", compute: 235.657, cloud: 57.343, amt: 2000, service: 55, dsktp: 375.44, mbl: 149.657, vsan: 554.4545, nsx: 443.3434, mgmt: 345.44, others: 543.34 },
    ],
    futurePipelineBackgrnd: {
        data: [
            ["others", "#7bd743"],
            ["mgmt", "#8377d9"],
            ["nsx", "#ffea63"],
            ["vsan", "#4184ff"],
            ["mbl", "#25ffc4"],
            ["dsktp", "#ffb1e8"],
            ["service", "#ffb7a8"],
            ["cloud", "#ff8073"],
            ["compute", "#66c1ff"],
        ]
    }
}
export default data;