const data =  {
    netSalesData: [
        { name: 'FY15', pv: 20000},
        { name: 'FY16', pv: 37000 },
        { name: 'FY17', pv: 1000}
    ],
    opIncomeData: [
        { name: 'FY15', pv: 2000, amt: 2000 },
        { name: 'FY16', pv: 1500, amt: 1500 },
        { name: 'FY17', pv: 3500, amt: 3500 }
    ],
    buPortfolioData: [
        { name: 'Industrial Automation', value: 100 },
        { name: 'Electronics Devices', value: 250 },
        { name: 'Energy & Electric', value: 200 },
        { name: 'Others', value: 450 }
    ],
    buPortfolioColors: ['#ffb1e8', '#66c1ff', '#ff8073', '#CFCFCF'],
}

export default data;
