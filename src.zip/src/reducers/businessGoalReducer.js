import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/business.json'
import _ from 'underscore';
import { ConfigConsumer } from 'antd/lib/config-provider';

export const businessGoal = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.GET_BUSINESS_GOALS: {
            newState = cloneDeep(state);
            newState.businessGoals = action.payload;
            return newState;
        }
        case types.GET_BUSINESS_INITIATIVES: {
            newState = cloneDeep(state);
            newState.businessInitiative = action.payload;
            return newState;
        }
        case types.GET_IT_INITIATIVES: {
            newState = cloneDeep(state);
            newState.ItInitiative = action.payload;
            return newState;
        }
        case types.GET_VMWARE_INITIATIVES: {
            newState = cloneDeep(state);
            newState.VMwareInitiative = action.payload;
            return newState;
        }
        case types.ADD_BUSINESS_DATA: {
            newState = cloneDeep(state);
            return newState;
        }
        case types.PUSH_BI_GOAL:{
            newState = cloneDeep(state);
            newState.businessGoals.push(action.payload);
            return newState
        }
        case types.CHANGE_BI_GOAL_NAME: {
            newState = cloneDeep(state);
            newState.businessGoals[action.payload.index].businessGoal = action.payload.data;
            return newState;
        }
        case types.DELETE_BUSINESS_GOAL:{
            newState = cloneDeep(state);
            newState.businessGoals.splice(action.payload,1);
            return newState;
        }
        case types.PUSH_BUSINESS_INITIATIVE:{
            newState = cloneDeep(state);
            newState.businessGoals[action.payload.index].businessInitiatives.push(action.payload.data);
            return newState;
        }
        case types.POP_BUSINESS_INITIATIVE:{
            newState = cloneDeep(state);
            newState.businessGoals[action.payload.goalIndex].businessInitiatives.splice(action.payload.biIndex,1);
            return newState;
        }
        case types.PUSH_IT_INITIATIVE:{
            newState = cloneDeep(state);
            newState.businessGoals[action.payload.goalIndex].businessInitiatives[action.payload.biIndex].itInitiatives.push(action.payload.data);
            return newState;
        }
        case types.POP_IT_INITIATIVE:{
            const {goalIndex,biIndex,itIndex} = action.payload
            newState = cloneDeep(state);
            newState.businessGoals[goalIndex].businessInitiatives[biIndex].itInitiatives.splice(itIndex,1);
            return newState;
        }
        case types.UPDATE_IT_INITIATIVE_NAME: {
            const {goalIndex,biIndex,itIndex,itGoal} = action.payload
            newState = cloneDeep(state);
            newState.businessGoals[goalIndex].businessInitiatives[biIndex].itInitiatives[itIndex].itGoal = itGoal;
            return newState;
        }
        case types.UPDATE_BUSINESS_INITIATIVE_NAME: {
            //const {goalIndex,biIndex,businessGoalInput} = action.payload
            newState = cloneDeep(state);
            newState.businessGoals[action.payload.goalIndex].businessInitiatives[action.payload.biIndex].businessInitiativeGoal= action.payload.businessGoalInput;
            return newState;
        }
        case types.PUSH_VMWARE_INITIATIVE:{
            const {goalIndex,biIndex,data} = action.payload
            newState = cloneDeep(state);
            newState.businessGoals[goalIndex].businessInitiatives[biIndex].wmwareInitiatives.push(data);
            return newState;
        }
        case types.POP_VMWARE_INITIATIVE: {
            const {goalIndex,biIndex,vmIndex} = action.payload
            newState = cloneDeep(state);
            newState.businessGoals[goalIndex].businessInitiatives[biIndex].wmwareInitiatives.splice(vmIndex,1);
            return newState;
        }
        case types.UPDATE_VMWARE_INITIATIVE:{
            const {goalIndex,biIndex,vmIndex,data} = action.payload
            newState = cloneDeep(state);
            newState.businessGoals[goalIndex].businessInitiatives[biIndex].wmwareInitiatives[vmIndex] = data;
            return newState;
        }
        default:{
            return state;
        }
     }
}