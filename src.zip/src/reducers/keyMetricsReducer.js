import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/keyMetrics.json'
import _ from 'underscore';

export const keyMetrics = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.GET_KEY_METRICS: {
            newState = cloneDeep(state);
            newState.keyMetrics = action.payload;
            return newState;
        }

        case types.UPDATE_DATA_POINTS :{
            newState = cloneDeep(state);
            newState.keyMetrics[action.payload.key] = parseFloat( action.payload.value);
            return newState;
        }
       
        default:{
            return state
        }
    }
}