import { cloneDeep } from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/strategy.json'
import _ from 'underscore';
import { ConfigConsumer } from 'antd/lib/config-provider';
import { CheckboxDataArray,CheckboxDataObject, CheckedboxLabelData } from '../Services/CheckboxData'

const searchOpportunity = ({searchInput,masterOpportunitiesDetails}) => {
    let opportunitiesDetails = masterOpportunitiesDetails;
    Object.keys(opportunitiesDetails).forEach(element => {
        opportunitiesDetails = {
            ...opportunitiesDetails,
            [element]: opportunitiesDetails[element].filter(e => {
                let oppNo = e.opportunityNo;
                let oppName = e.opportunityName ;
                return oppNo.includes(searchInput) || oppName.includes(searchInput)
                //return inputVal.indexOf(searchInput) > 0 ? true : false
            })
        };
    });
    return {
        opportunitiesDetails
    }
}

const filterDataPoints = ({filterValues, masterOpportunitiesGraph, masterOpportunitiesDetails }) => {
    // logic here
    const keyMap = {
        QUARTER: 'fiscalPeriod',
        STAGE: 'stageName',
        PRODUCT: 'platformGroup',
        EVP: 'evpFlag'
    }
    
    let opportunitiesGraph = masterOpportunitiesGraph;
    let opportunitiesDetails = masterOpportunitiesDetails;
    
    // opportunitiesGraph
    Object.entries(keyMap).forEach(([keyName, key]) => {
        switch(keyName) {
            case "QUARTER":
            case "STAGE":
            case "PRODUCT": {
                opportunitiesGraph = opportunitiesGraph.filter(e => {
                    const filterValue = e[key];
                    return filterValues[keyName] !== undefined && filterValues[keyName].length ? filterValues[keyName].includes(filterValue) : true;
                });
                break;
            }
            case "EVP": {
                opportunitiesGraph = opportunitiesGraph.filter(e => {
                    const filterValue = e[key];
                    return filterValues[keyName] !== undefined ? filterValues[keyName] === filterValue : true;
                });
            }
        }
    });

        
    // opportunitiesDetails
    Object.entries(keyMap).forEach(([keyName, key]) => {
        switch(keyName) {
            case "QUARTER":
            case "STAGE": {
                Object.keys(opportunitiesDetails).forEach(element => {
                    opportunitiesDetails = {
                        ...opportunitiesDetails,
                        [element]: opportunitiesDetails[element].filter(e => {
                            const filterValue = e[key];
                            return filterValues[keyName] !== undefined && filterValues[keyName].length ? filterValues[keyName].includes(filterValue) : true;
                        })
                    };
                });
                break;
            }
            case "EVP": {
                Object.keys(opportunitiesDetails).forEach(element => {
                    opportunitiesDetails = {
                        ...opportunitiesDetails,
                        [element]: opportunitiesDetails[element].filter(e => {
                            const filterValue = e[key];
                            return filterValues[keyName] !== undefined ? filterValues[keyName] === filterValue : true;
                        })
                    };
                });
                break;
            }
            case "PRODUCT": {
                Object.keys(opportunitiesDetails).forEach(element => {
                    opportunitiesDetails = {
                        ...opportunitiesDetails,
                        [element]: opportunitiesDetails[element].filter(e => {
                            const filterable = e['productDetails'] || [];
                            return filterable.some(el => filterValues[keyName] !== undefined && filterValues[keyName].length ? filterValues[keyName].includes(el[key]) : true);
                        })
                    };
                });
                break;
            }
        }
    });
    
    return {
        opportunitiesGraph,
        opportunitiesDetails
    }
}

export const strategy = (state = initialState, action = {}) => {
    let newState = {};
    switch (action.type) {
        // case types.CHANGE_KEY_THEME_FIELD: {
        //     newState = cloneDeep(state);
        //     newState.keyMetrics = action.payload;
        //     return newState;
        // }
        case types.CHANGE_KEY_THEME_FIELD: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload.index].ambitionPlan === null) {
                newState.threeYearAmbition[action.payload.index].ambitionPlan = { keyTheme: "", targetValue: "", growthStrategy: [""] };
            }
            newState.threeYearAmbition[action.payload.index].ambitionPlan.keyTheme = action.payload.value
            return newState;
        }
        case types.CHANGE_TARGET_VALUE_FIELD: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload.index].ambitionPlan === null) {
                newState.threeYearAmbition[action.payload.index].ambitionPlan = { keyTheme: "", targetValue: "", growthStrategy: [""] };
            }
            newState.threeYearAmbition[action.payload.index].ambitionPlan.targetValue = action.payload.value
            return newState;
        }
        case types.CHANGE_GROWTH_STRATEGY_FIELD: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload.index].ambitionPlan === null) {
                newState.threeYearAmbition[action.payload.index].ambitionPlan = { keyTheme: "", targetValue: "", growthStrategy: [""] };
            }
            newState.threeYearAmbition[action.payload.index].ambitionPlan.growthStrategy[action.payload.growth_index] = action.payload.value
            return newState;
        }

        case types.FETCH_THREE_YEAR_AMBITION: {
            newState = cloneDeep(state);
            newState.threeYearAmbition = action.payload;
            return newState;
        }

        case types.FETCH_AMBITION_GOAL_PLAN: {
            newState = cloneDeep(state);
            newState.goalPlan = action.payload.teamGoal;
            newState.accountTeamGoalId = action.payload.accountTeamGoalId;
            return newState;
        }
        case types.SET_TEAM_GOAL_ID: {
            newState = cloneDeep(state);
            newState.accountTeamGoalId = action.payload;
            return newState;
        }

        // case types.SUBMIT_AMBITION_GOAL_PLAN:{
        //     newState = cloneDeep(state);
        //     //newState.threeYearAmbition = action.payload;
        //     console.log(action.payload);
        //     return newState;
        // }
        case types.POST_AMBITION_GOAL_PLAN: {
            newState = cloneDeep(state);
            newState.threeYearAmbition = action.payload;
            return newState;
        }
        case types.ADD_MORE: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload].ambitionPlan == null) {
                newState.threeYearAmbition[action.payload].ambitionPlan = {
                    growthStrategy: []
                }
            }
            newState.threeYearAmbition[action.payload].ambitionPlan.growthStrategy.push("");
            return newState;

        }
        case types.DELETE_ELEMENT: {
            newState = cloneDeep(state);
            newState.threeYearAmbition[action.payload.index].ambitionPlan.growthStrategy.splice(action.payload.growth_index, 1);
            return newState;
        }

        case types.DELETE_GOAL_ELEMENT: {
            newState = cloneDeep(state);
            newState.goalPlan.splice(action.payload, 1);
            return newState;
        }

        case types.ADD_MORE_GOAL: {
            newState = cloneDeep(state);
            newState.goalPlan.push("");
            return newState;
        }

        case types.ADD_TEAM_GOAL_DATA: {
            newState = cloneDeep(state);
            newState.goalPlan.accountTeamGoalId = "";

            return newState;
        }

        case types.ADD_GOAL_VALUE: {
            newState = cloneDeep(state);
            newState.goalPlan.teamGoal.push("");
            newState.goalPlan.accountTeamGoalId = null;
            return newState;
        }
        case types.CHANGE_GOAL_VALUE: {
            newState = cloneDeep(state);
            newState.goalPlan[action.payload.index] = action.payload.value;
            return newState;
        }

        case types.RESET_AMBITION:{
            newState = cloneDeep(state);
            newState.threeYearAmbition[action.payload.index] = action.payload.ambition;
            return newState;
        }
        
        case types.STORE_DROPDOWN_VAL: {
            newState = cloneDeep(state);
            switch(action.payload.title){
                case "QUARTER" :
                            newState.KeyOpportunities.filterDetails.dropdownQuarter = action.payload.value;
                            break;
                case "STAGE" :
                            newState.KeyOpportunities.filterDetails.dropdownStage = action.payload.value;
                            break;
                case "PRODUCT" :
                            newState.KeyOpportunities.filterDetails.dropdownProduct = action.payload.value;
                            break;
            default:
                        break;
        }
            return newState;
        }
        case types.CHANGE_CHECKBOX: {
            newState = cloneDeep(state);
            switch(action.payload.title){
                case "QUARTER" :
                            newState.KeyOpportunities.filterValues[action.payload.title] = action.payload.labelData;
                            newState.KeyOpportunities.filterDetails.labelsQuarter = action.payload.labelData;
                            newState.KeyOpportunities.filterDetails.dropdownQuarter = action.payload.checkedBox;
                            newState.KeyOpportunities = {...newState.KeyOpportunities, ...filterDataPoints(newState.KeyOpportunities)};
                            break;
                case "STAGE" :
                            newState.KeyOpportunities.filterValues[action.payload.title] = action.payload.labelData;
                            newState.KeyOpportunities.filterDetails.labelsStage = action.payload.labelData;
                            newState.KeyOpportunities.filterDetails.dropdownStage = action.payload.checkedBox;
                            newState.KeyOpportunities = {...newState.KeyOpportunities, ...filterDataPoints(newState.KeyOpportunities)};
                            break;
                case "PRODUCT" :
                            newState.KeyOpportunities.filterValues[action.payload.title] = action.payload.labelData;
                            newState.KeyOpportunities.filterDetails.labelsProduct = action.payload.labelData;
                            newState.KeyOpportunities.filterDetails.dropdownProduct = action.payload.checkedBox;
                            newState.KeyOpportunities = {...newState.KeyOpportunities, ...filterDataPoints(newState.KeyOpportunities)};
                            break;
                default:
                        break;
        }
            return newState;
        }
        case types.SEARCH_OPPORTUNITY: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.searchInput = action.payload.input;
            newState.KeyOpportunities = {...newState.KeyOpportunities, ...searchOpportunity(newState.KeyOpportunities)};
            return newState;
        }
        case types.CHANGE_EVP: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.filterValues['EVP'] = action.payload.val === "yes" ? 1 : 0;
            newState.KeyOpportunities.filterDetails.evp = action.payload;
            newState.KeyOpportunities = {...newState.KeyOpportunities, ...filterDataPoints(newState.KeyOpportunities)};
            return newState;
        }
        //key opportunities
        case types.FETCH_QUARTERS: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.quarters = action.payload;
            return newState;
        }
        case types.FETCH_STAGE: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.stage = action.payload;
            return newState;
        }
        case types.FETCH_PRODUCTS: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.products = action.payload;
            return newState;
        }
        case types.FETCH_GRAPH_OPPORTUNITIES: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.opportunitiesGraph = action.payload;
            newState.KeyOpportunities.masterOpportunitiesGraph = [...action.payload];
            return newState;
        }
        case types.FETCH_OPPORTUNITIES_DETAILS: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.opportunitiesDetails = action.payload;
            newState.KeyOpportunities.masterOpportunitiesDetails = {...action.payload};
            return newState;
        }
        case types.SET_MAX_RANGE: {
            newState = cloneDeep(state);
            newState.KeyOpportunities.maxRange = action.payload;
            return newState;
        }

        default: {
            return state;
        }
    }
}