import React, { Component } from 'react';
import PropTypes from "prop-types";
import HeaderInfo from '../common/HeaderInfo/HeaderInfo';
import TagInfo from '../common/TagInfo/TagInfo';
import MainContent from './MainContent/MainContent';

class AccountPlan extends Component {
    componentDidMount(){
        //if(this.props.landing.selectedAccount === null){
            // this.props.actions.getAccountDetails({
            //     accountId: this.props.match.params.accountId
            // },-1);
            this.props.actions.getAccountByAccountId(this.props.match.params.accountId)
        //}
    }
    render = () => {
        
        return (
            <div>
                {
                    this.props.landing.plans.length > 0 &&
                    <HeaderInfo accounts={[
                        this.props.landing.plans[0].accountPlanName.substr(0,this.props.landing.plans[0].accountPlanName.length-6), 
                        this.props.landing.plans[0].accountPlanName
                    ]} percent={27} status="Completed" />
                    
                }
                
                <TagInfo 
                    sectionTagTxt="Only show sections I’m tagged in" 
                    sectionTagChecked={false} 
                    commentTagTxt="Only show sections with comments"
                    commentTagChecked={false}
                />
                <MainContent 
                    overviewReducer={this.props.overviewReducer}
                    footprintReducer={this.props.footprintReducer} 
                    keyMetricsReducer={this.props.keyMetricsReducer}
                    strategyReducer={this.props.strategyReducer}
                    actions={this.props.actions} 
                    accountPlanId={this.props.match.params.accountPlanId}
                    accountId={this.props.match.params.accountId}
                    businessGoalReducer={this.props.businessGoal}
                    landingReducer={this.props.landing}
                />
            </div>
        );
    }
}

AccountPlan.propTypes = {
    overviewReducer: PropTypes.object,
    keyMetricsReducer:PropTypes.object,
    strategyReducer:PropTypes.object,
    footprintReducer: PropTypes.object,
    actions: PropTypes.object,
    match: PropTypes.object,
    businessGoal: PropTypes.object,
    location: PropTypes.object
};


export default AccountPlan;