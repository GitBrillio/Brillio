import React,{Component} from 'react';
import PropTypes from "prop-types";
import './StrategyAction.scss';
import '../MainContent.scss';
import { Layout, Menu, Icon,Collapse } from 'antd';
const {Content } = Layout;
import VmInput from '../../common/VmInput/VmInput';
import VmSelect from '../../common/VmSelect/VmSelect';
import VmTextarea from '../../common/VmTextarea/VmTextarea';
import VmFloatingInput from '../../common/VmFloatingInput/VmFloatingInput';
import BarChrt from '../../common/Charts/BarChart/BarChrt';
import PieChrt from '../../common/Charts/PieChart/PieChrt';
const Panel = Collapse.Panel;

export default class StrategyAction extends Component {
    constructor(props) {
        super(props);
        this.state={
           
        }
    }
    render(){
        return (
            <div className="strategy-action">
                <Layout>
                        <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                            <div className="menu-selected">Footprint</div>
                            <div className="submenu-selected">VMware Bookings</div>
                            <Collapse defaultActiveKey={['1']}>
                                <Panel header={<div className="collapse-main">
                                                    <span className="collapse-header">By Product Group</span>
                                                    <span className="red-star">*</span>
                                                    <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                                    <Icon type="info-circle-o" style={{color:'#007cbb'}} />
                                                </div>} key="1">
                                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        
                                        
                                    </div>
                                    
                                </Panel>
                            </Collapse>
    
                            <Collapse className="collapse-margin">
                                <Panel header={<div className="collapse-main">
                                                    <span className="collapse-header">By Product Class</span>
                                                    <span className="red-star">*</span>
                                                    <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                                    <Icon type="info-circle-o" style={{color:'#007cbb'}} />
                                                </div>} key="2">
                                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                            
                                        </div>
                                        <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                          
                                        </div>
                                    </div>

                                </Panel>
                            </Collapse>

                            <Collapse className="collapse-margin">
                                <Panel header={<div className="collapse-main">
                                                    <span className="collapse-header">Spend History: ELA and Transaction Purchases</span>
                                                    <span className="red-star">*</span>
                                                    <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                                    <Icon type="info-circle-o" style={{color:'#007cbb'}} />
                                                </div>} key="2">
                                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                            
                                        </div>
                                        <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                          
                                        </div>
                                    </div>

                                </Panel>
                            </Collapse>

                            <Collapse className="collapse-margin">
                                <Panel header={<div className="collapse-main">
                                                    <span className="collapse-header">Future Pipeline: by Product Group</span>
                                                    <span className="red-star">*</span>
                                                    <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                                    <Icon type="info-circle-o" style={{color:'#007cbb'}} />
                                                </div>} key="2">
                                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                            
                                        </div>
                                        <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                          
                                        </div>
                                    </div>

                                </Panel>
                            </Collapse>
    
                            
                        </Content>
                    </Layout>
            </div>
        );
    }
};

