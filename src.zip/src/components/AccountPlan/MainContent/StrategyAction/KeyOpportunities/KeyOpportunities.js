import React, { Component } from 'react';
import { Layout } from 'antd';
import PropTypes from 'prop-types';
import './key-opportunities.scss';
import OverallView from './OverallView/overallview';
import SearchAndFilter from './SearchAndFilter/search-and-filter';
import OpportunityDetails from './OpportunityDetails/OpportunityDetails';
const { Content } = Layout;

class KeyOpportunities extends Component{
    componentDidMount(){
        // make the action call
        this.props.actions.getQuarters();
        this.props.actions.getStage();
        this.props.actions.getProducts();
        this.props.actions.getGraphOpportunities(this.props.accountId); //0018000000hoEG2AAM
        this.props.actions.getOpportunitiesDetails(this.props.accountId); 
    }
    render = () =>{
        return (
            <section className="key-opportunities">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3 className="h3-style">Strategy & Actions</h3>
                        <h1>Key Opportunities</h1>
                        <div>
                            {
                                this.props.strategyReducer.KeyOpportunities.quarters 
                                    && this.props.strategyReducer.KeyOpportunities.stage 
                                    && this.props.strategyReducer.KeyOpportunities.products &&
                                    <SearchAndFilter 
                                        actions={this.props.actions}
                                        keyOpportunitiesReducer = {this.props.strategyReducer.KeyOpportunities}
                                    />
                            }
                            {
                                this.props.strategyReducer.KeyOpportunities.opportunitiesGraph.length > 0 && 
                                <OverallView 
                                    opportunitiesGraph = {this.props.strategyReducer.KeyOpportunities.opportunitiesGraph}
                                />
                            }
                            <OpportunityDetails 
                                opportunitiesDetails = {this.props.strategyReducer.KeyOpportunities.opportunitiesDetails}
                            />
                            
                        </div>
                    </Content>
                </Layout>
            </section>
        )
    }
}

KeyOpportunities.propTypes = {
    strategyReducer: PropTypes.object,
    actions: PropTypes.object,
    accountId : PropTypes.string
}

export default KeyOpportunities;
