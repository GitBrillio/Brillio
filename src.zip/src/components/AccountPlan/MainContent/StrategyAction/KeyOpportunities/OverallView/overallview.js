import React,{Component} from 'react';
import { Collapse,Row } from 'antd'; //Input
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Cell,Legend,Tooltip } from 'recharts';
import './overallview.scss';
import PropTypes from 'prop-types';
import { graphLegendData, graphData } from "../../../../../../Services/graphData"
const Panel = Collapse.Panel;

const colors = ["#F2519B", "#A062FF", "#75B6C8", "#FFDB00", "#CD895D", "#DE52DB", "#54AEFF", "#FF7587", "#FFB1E8", "#8075C8", "#54AEFF", "#00EBFF", "#6BC764", "#2C964C", "#A1A1A1"];

class OverallView extends Component{
    render(){
        return(
            <Collapse defaultActiveKey={['1']} className="wrapper">
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Overall View</span>
                    
                </div>}key='1'>
                <section>
                    <Row className="bar-area">
                        <BarChart 
                                width={window.screen.width - (document.querySelector(".left-navbar").scrollWidth + 100) } 
                                height={300} 
                                data={graphData(this.props.opportunitiesGraph)}
                                margin={{top: 5, right: 10, left: 20, bottom: 20}}>
                            <CartesianGrid 
                                vertical={false}
                                stroke="#ebf3f0"
                            />
                            <XAxis dataKey="name"/>
                            <YAxis axisLine={false}/>
                            <Bar dataKey="pv" fill="#8075C8" barSize={10} radius={[8,8,0,0]}>
                                {
                                    graphData(this.props.opportunitiesGraph).map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={colors[index % 20]}/>
                                    ))
                                }
                            </Bar>
                                <Legend content={
                                    <ul style={{listStyleType: "none"}}>
                                    {
                                        graphLegendData(graphData(this.props.opportunitiesGraph),colors).map((entry, index) => (
                                            <li key={`item-${index}`} style={{display:"inline-block",marginLeft:"25px"}}><div style={{width:"10px",height:"10px",backgroundColor: entry.color ,borderRadius:"50%",display: "inline-block"}}></div><span style={{marginLeft:"5px"}}>{entry.label}</span></li>
                                        ))
                                    }
                                    </ul>
                                } />
                             <Tooltip/>
                        </BarChart>
                    </Row>
                </section>
            </Panel>
        </Collapse>
        )
    }
}
OverallView.propTypes = {
    opportunitiesGraph: PropTypes.object
}
export default OverallView;