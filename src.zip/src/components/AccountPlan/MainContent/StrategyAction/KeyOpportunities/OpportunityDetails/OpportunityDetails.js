import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Heading from './Heading/Heading';

class OpportunityDetails extends Component {

    render() {

        return (
            <div className="opportunity-details">
                {
                    this.props.opportunitiesDetails &&
                    Object.keys(this.props.opportunitiesDetails).map((obj, index) => {
                        return(
                            <Heading
                                key={index}
                                headerText={obj}
                                opportunity={this.props.opportunitiesDetails[obj]}
                            />
                        )
                    })

                }
            </div>
        )
    }
}
OpportunityDetails.propTypes = {
    opportunitiesDetails: PropTypes.object
}
export default OpportunityDetails;