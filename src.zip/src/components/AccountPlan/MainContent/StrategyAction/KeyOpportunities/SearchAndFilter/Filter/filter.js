import React,{Component} from 'react';
import { Slider,Row, Col, Select} from 'antd'; //Input
import './filter.scss';
import PropTypes from 'prop-types';
import close from './Close.png';
import CustomDropdown from '../../../../../../common/customDropdown/CustomDropdown';
import { CheckboxDataArray,CheckboxDataObject} from '../../../../../../../Services/CheckboxData';
const Option = Select.Option;

class Filter extends Component{
    componentWillMount(){
        let dropdownQuarter = CheckboxDataArray(this.props.keyOpportunitiesReducer.quarters);
        this.props.actions.storeDropdownValues("QUARTER",dropdownQuarter);
        let dropdownStage = CheckboxDataObject(this.props.keyOpportunitiesReducer.stage);
        this.props.actions.storeDropdownValues("STAGE",dropdownStage);
        let dropdownProduct = CheckboxDataObject(this.props.keyOpportunitiesReducer.products);
        this.props.actions.storeDropdownValues("PRODUCT",dropdownProduct);      
    }
    
     render(){
        let marks={
            0:'0',
            100:this.props.keyOpportunitiesReducer.maxRange ? this.props.keyOpportunitiesReducer.maxRange : 2000
        }
            return(
                    this.props.keyOpportunitiesReducer.filterDetails && 
                    <Row gutter={20} className="filter-key-opp p-t-10">
                        <Col span={4}>
                            <CustomDropdown 
                                title="QUARTER" 
                                val={this.props.keyOpportunitiesReducer.filterDetails.dropdownQuarter} 
                                selectedCheckboxes = {this.props.keyOpportunitiesReducer.filterDetails.labelsQuarter}
                                placeholder="Select Quarter"
                                onChange={(e,key,val,title)=>{
                                    this.props.actions.onChangeCheckbox(e,key,val,title)
                                }} 
                            />
                        </Col>
                        <Col span={4}>
                            <CustomDropdown 
                                title="STAGE" 
                                val={this.props.keyOpportunitiesReducer.filterDetails.dropdownStage} 
                                selectedCheckboxes = { this.props.keyOpportunitiesReducer.filterDetails.labelsStage}
                                placeholder="Select Stage"
                                onChange={(e,key,val,title)=>{
                                    this.props.actions.onChangeCheckbox(e,key,val,title)
                                }} 
                            />
                        </Col>
                        <Col span={5}>
                            <CustomDropdown 
                                title="PRODUCT" 
                                val={this.props.keyOpportunitiesReducer.filterDetails.dropdownProduct} 
                                selectedCheckboxes = { this.props.keyOpportunitiesReducer.filterDetails.labelsProduct}
                                placeholder="Select Product"
                                onChange={(e,key,val,title)=>{
                                    this.props.actions.onChangeCheckbox(e,key,val,title)
                                }} 
                            />
                        </Col>
                        <Col span={3} className="ela-main">
                            <label className="label-style">EVP</label>
                            <Select 
                                className="ELA-select" 
                                placeholder="Select" 
                                labelInValue
                                onChange={(e)=>{
                                    this.props.actions.onChangeSelectEVP(e.key)
                                }} 
                            >
                                <Option value="yes">Yes</Option>
                                <Option value="no">No</Option>
                            </Select>
                        </Col>

                        <Col span={4} className="slider-main" style={{visibility:'hidden'}}>
                            <p className="label-style">DEAL RANGE</p>
                            <Slider range step={10} marks={marks} defaultValue={[0,100]} />
                        </Col>

                        <Col span={3}>
                        </Col>
                        
                        <Col span={1} className="close-icon">
                            <img src={close} onClick = {()=>this.props.handlefilterStatus(false)} />
                        </Col>
                    </Row>
            )
        }
}
Filter.propTypes = {
    handlefilterStatus: PropTypes.func,
    actions: PropTypes.object,
    keyOpportunitiesReducer: PropTypes.object
}

export default Filter;