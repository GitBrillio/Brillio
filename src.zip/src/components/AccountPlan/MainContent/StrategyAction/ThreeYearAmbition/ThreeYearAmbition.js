import React, { Component } from 'react';
import { Layout } from 'antd';
import './three-year-ambition.scss';
import PropTypes from 'prop-types';
import AccountTeamGoals from './AccountTeamGoals/AccountTeamGoals';
import AccountTeamGoalPlan from './AccountTeamGoalPlan/AccountTeamGoalPlan';
const { Content } = Layout;

class ThreeYearAmbition extends Component{
    componentDidMount(){
        // make the action call
        this.props.actions.getThreeYearAmbition(
            this.props.accountPlanId
        );
        this.props.actions.getAmbitionsGoalPlan(this.props.accountPlanId);
       
    }
    render = () =>{
        return (
            <section className="three-year-ambition">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3>Strategy & Actions</h3>
                        <h1>3-year Ambition</h1>
                        <div className="left-sub-txt">
                            <div>Last updated</div>
                            <div>by John Smith on Aug 11, 2017</div>
                        </div>
                        <div className="row">
                            <div className="col-lg-12">
                                <AccountTeamGoalPlan 
                                    actions={this.props.actions}
                                    ambitions={this.props.strategyReducer.threeYearAmbition}
                                    accountPlanId={this.props.accountPlanId}
                                />
                                <br/>
                                <AccountTeamGoals
                                    actions={this.props.actions}
                                    goalPlan={this.props.strategyReducer.goalPlan}
                                    accountPlanId={this.props.accountPlanId}
                                    accountTeamGoalId={this.props.strategyReducer.accountTeamGoalId}
                                />
                            </div>
                        </div>
                    </Content>
                </Layout>
                
            </section>
        )
    }
}

ThreeYearAmbition.propTypes = {
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    strategyReducer: PropTypes.object
}

export default ThreeYearAmbition;
