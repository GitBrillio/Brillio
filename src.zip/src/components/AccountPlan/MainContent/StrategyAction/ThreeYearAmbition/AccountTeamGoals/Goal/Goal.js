import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Icon } from 'antd';
import VmTextareaMaterial from '../../../../../../common/VmTextarea/VmTextareaMaterial';
import Input from 'muicss/lib/react/input';
import './goal.scss';


class Goal extends Component {
    render = () => {
        //const {system,actions,type,systemIndex,deleteSystem} = this.props;

        return (
            <section className="goal">
                    <div>
                        <div className="width-97" style={{padding:'0 0 0 4px'}}>
                                <Input 
                                    label={"Enter Team Goal"}
                                    value= {this.props.teamGoal} 
                                    floatingLabel={true} 
                                    onChange={(e)=>this.props.actions.changeGoalValue(e.target.value,this.props.index)}
                                    onBlur ={()=>this.props.actions.submitGoalPlan(this.props.goalPlan,this.props.accountPlanId,this.props.accountTeamGoalId)}
                                />
                        </div>
                                <div className="width-3" style={{marginTop:18}}>
                                    <Icon className="minus-circle" type="minus-circle-o" onClick={()=>this.props.actions.deleteGoalElement(this.props.index,this.props.goalPlan,this.props.accountPlanId,this.props.accountTeamGoalId)}/>
                                </div> 
                               
                    </div>
            </section>
        )
    }
}

Goal.propTypes = {
    actions: PropTypes.object,
    goalPlan :PropTypes.any,
    accountPlanId : PropTypes.string,
    accountTeamGoalId: PropTypes.string,
    teamGoal: PropTypes.any,
    index: PropTypes.number
}

export default Goal;