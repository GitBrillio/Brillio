import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './team-goal-plan.scss';
import { Row, Col } from 'antd';
import GrowthStrategy from './GrowthStrategy/GrowthStrategy';
import {KMB} from '../../../../../../Services/Common';


class AccountTeamGoalPlan extends Component {

    getSize = (index) => {
        switch (index) {
            case 0: return 150;
            case 1: return 215;
            case 2: return 265;
            case 3: return 315;
            default: return 150;
        }
    }

    getline(index) {
        switch (index) {
            case 0:
                return {
                    x1: 300, y1: 0, x2: 76, y2: 60
                }
            case 1:
                return {
                    x1: 335, y1: 0, x2: 76, y2: 60
                }
            case 2:
                return {
                    x1: 330, y1: 0, x2: 76, y2: 50
                }
            case 3:
                return {
                    x1: 200, y1: 20, x2: 73, y2: 50
                }
            default:
                return{
                    x1: 0, y1: 0, x2: 0, y2: 0
                }
        }
    }
    getBooking(ambition){ 
        try{
            if(typeof ambition !== "undefined" && typeof (ambition[0].ambitionPlan) !== "undefined"){
                return KMB(ambition[0].ambitionPlan.targetValue)
            }
            else{
                return 0;
            }
        }
        catch(e){

        }
    }

    getSum(ambition){
        let sum = 0
        if(ambition.length > 0){
            for(let i=1 ;i < ambition.length; i++){
                let v = ambition[i].ambitionPlan === null ? 0 : parseInt(ambition[i].ambitionPlan.targetValue ==="" ? 0 : ambition[i].ambitionPlan.targetValue )
                sum += v
            }
        }
        return KMB(sum);

    }

    render() {
        const { ambitions } = this.props;
       
        return (
            <div>
                <div className="gutter-example">
                    <Row gutter={16} className="growth-strategy-main">


                        {
                            ambitions && ambitions.map((ambition, index) => (
                                <Col className="gutter-row" span={6} key={index}>
                                    <GrowthStrategy
                                        actions={this.props.actions}
                                        size={this.getSize(index)}
                                        index = {index}
                                        ambition={ambition}
                                        border={index > 0 ? 'blue' : ''}
                                        line={this.getline(index)}
                                        strategyReducer={this.props.strategyReducer}
                                        accountPlanId={this.props.accountPlanId}
                                    />
                                </Col>
                            ))
                        }
                       
                    </Row>
                </div>
                <div className="growth-strategy-amount">
                    {ambitions && ambitions.length > 0 &&
                        <Row>
                            <Col className="gutter-row text-center border-bottom row-one" span={6}>
                                <label>FY {ambitions[0].fiscalYear - 2000} Bookings to date: $ {ambitions && this.getBooking(ambitions)}</label>
                            </Col>
                            <Col className="gutter-row text-center border-bottom row-two" span={17} >
                                <label>3 Year Ambition: $ {this.getSum(ambitions)} </label>
                            </Col>
                        </Row>
                    }
                </div>
            </div>

        )
    }
}

AccountTeamGoalPlan.propTypes = {
    actions: PropTypes.object,
    ambitions: PropTypes.any,
    strategyReducer: PropTypes.object,
    accountPlanId: PropTypes.string
}


export default AccountTeamGoalPlan;