import React, { Component } from 'react';
import { Modal, Button} from 'antd';
// import './AddNewBusinessInitiative.scss';
import VmWareInitiativeInput from './VmWareInitiativeInput';
import DeletePopup from '../../../../../common/DeletePopup/DeletePopup';

class AddNewVMwareInitiative extends Component{
    constructor(props) {
        super(props);
        this.state = {
            confirmDelete: false
        }
    }

    ConfHandleCancel = () => {
        this.setState({confirmDelete : false});
    }

    validateForm() {
        if(this.props.vmName != "") {
            this.props.handleSave();
        }
    }

    render = () =>{
        let deleteBtn = "";
        if (this.props.vmId != null){
            deleteBtn = <Button key="submit" type="danger" onClick={() => this.setState({ confirmDelete: true })}>Delete</Button>
        }
        return (
            <div className="add-edit-new-group">
            { this.props.visible && <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    deleteBtn,
                    <Button key="submit" type="primary" onClick={()=>this.validateForm()}>
                        Save
                    </Button>
                ]}
            >
                <VmWareInitiativeInput 
                    biName = {this.props.biName}
                    vmWareInputVal = {this.props.vmWareInputVal}
                    vmName = {this.props.vmName}
                />
               
            </Modal>}

             {this.state.confirmDelete && 
            <DeletePopup 
                heading="Delete VMware initiative"
                visible={this.state.confirmDelete} 
                ok={()=>this.props.handleDelete(this.state)} 
                cancel={()=>this.ConfHandleCancel()} 
                okText="Yes delete it" 
                cancelText="No, cancel it" 
                contents="Are you sure you want to delete this VMware Initative ?" 
            />
        
        
            }

        </div>
        )
    }

}

AddNewVMwareInitiative.propTypes = {
}

export default AddNewVMwareInitiative;