import React, { Component } from 'react';
import { Modal, Button,message} from 'antd';
import './AddNewBusinessInitiative.scss';
import BusinessInitiativeInput from './BusinessInitiativeInput';
import Config from '../../../../../../config/Config';
import axios from 'axios';
import DeletePopup from '../../../../../common/DeletePopup/DeletePopup';
const conf = new Config()

class AddNewBusinessInitiative extends Component{

    constructor(props) {
        super(props);
        this.state = {
            accountPlanId: this.props.accountPlanId,
            budget: "",
            businessGoalId: this.props.goalId,
            businessInitiativeId: this.props.businessInitiativesId,
            executiveSponsor: "",
            goal: "",
            initiativeLeader: "",
            initiativeName: "",
            linkStatus: 1,
            objectiveAndMetrics: "",
            timeHorizon: "",
            confirmDelete: false,
            new: true
        }
    }

    componentDidMount() {
        if(this.props.businessInitiativesId) {
            this.getBusinessInitiatives(this.props.accountPlanId, this.props.businessInitiativesId);
        }
    }
    getBusinessInitiatives = (accountPlanId,biInitiativeId) => {
        const msg = message.loading("Loading bussiness initiative",0);
        let params = {
            method: conf.getBusinessGoals.method,
            url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/bi?id="+biInitiativeId
        }
        axios(params).then(response => {
            if (response.status === 200) {
                this.setState({
                    budget: response.data.data.budget,
                    executiveSponsor: response.data.data.executiveSponsor,
                    goal: response.data.data.goal,
                    initiativeLeader: response.data.data.initiativeLeader,
                    initiativeName: response.data.data.initiativeName,
                    linkStatus: response.data.data.linkStatus,
                    objectiveAndMetrics: response.data.data.objectiveAndMetrics,
                    timeHorizon: response.data.data.timeHorizon,
                    new: false
                })
            }
            else{
                message.error('Error in fetching Business Initiatives.');
            }
            msg()
        });
    }

    handleChange = (e) =>{
        switch(e.target.name){
            case "biName": {
                this.setState({goal : e.target.value});
                break;
            }
            case "time": {
                this.setState({timeHorizon : e.target.value});
                break;
            }
            case "objective": {
                this.setState({objectiveAndMetrics : e.target.value});
                break;
            }
            case "initiativeLeader": {
                this.setState({initiativeLeader : e.target.value});
                break;
            }
            case "budget": {
                this.setState({budget : e.target.value});
                break;
            }
            case "executiveSponser": {
                this.setState({executiveSponsor : e.target.value});
                break;
            }
            case "linkStatus": {
                this.setState({linkStatus : e.target.value});
                break;
            }
            default:{
                break;
            }
        }
    }

    ConfHandleCancel = () => {
        this.setState({confirmDelete : false});
    }

    validateForm() {
        if(this.state.goal != "") {
            this.props.handleSave(this.state,this.state.new);
        }
    }

    render = () =>{
        let deleteBtn;
        if (this.props.businessInitiativesId != null){
            deleteBtn = <Button key="submit" type="danger" onClick={() => this.setState({ confirmDelete: true })}>Delete</Button>
        }
        return (
            <div className="add-edit-new-group">
            { this.props.visible && <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                onCancel={this.props.handleCancel}
                footer={[
                    deleteBtn, 
                    <Button key="submit" type="primary" onClick={()=>this.validateForm()}>
                        Save
                    </Button>,
                ]}
            >
                <BusinessInitiativeInput
                    businessGoalInput = {this.props.businessGoalInput}                    
                    actions = {this.props.actions}
                    handleChangeVal = {(e)=>this.handleChange(e)}
                    targetValue = {this.state}
                />
            </Modal> }
            {this.state.confirmDelete && 
            <DeletePopup 
                heading="Delete Business initiative"
                visible={this.state.confirmDelete} 
                ok={()=>this.props.handleDelete(this.state)} 
                cancel={()=>this.ConfHandleCancel()} 
                okText="Yes delete it" 
                cancelText="No, cancel it" 
                contents="Are you sure you want to delete the Business Initative ?" 
                subContents={
                    <div>
                        
                            <div>
                                <span className="will-also">Will also delete</span><br/>
                                <p className="blue-text">
                                    {this.props.businessGoalReducer.businessGoals[this.props.goalIndex].businessInitiatives[this.props.biIndex].itInitiatives.length} IT initiative(s), and &nbsp;
                                    {this.props.businessGoalReducer.businessGoals[this.props.goalIndex].businessInitiatives[this.props.biIndex].wmwareInitiatives.length} VMware Initative(s)
                                </p>
                            </div>
                        
                    </div>
                }
            />
        
        }

        </div>
        )
    }

}

AddNewBusinessInitiative.propTypes = {
}

export default AddNewBusinessInitiative;