import React, { Component } from 'react';
import Input from 'muicss/lib/react/input';
import './AddNewBusinessInitiative.scss';
import { Row, Col, Radio, Calendar } from 'antd';
import InputITAlignment from '../../../../../common/InputITAlignment/InputITAlignment';
const RadioGroup = Radio.Group;

class BusinessInitiativeInput extends Component {
    render = () => {
        return (
            <div>
                <Row padding-bottom>
                    <Col span={14}>
                        <p className="par">DETAILS</p>
                    </Col>
                    <Col span={10}>
                        <p className="par">SCHEDULE</p>
                    </Col>
                </Row>
                <Row gutter={32} className="business-initiative-block-main">
                    <Col className="gutter-row padding" span={14}>
                        <Input
                            autoComplete="off"
                            value={this.props.businessGoalInput}
                            label={"Goal"}
                            floatingLabel={true}
                            disabled={true}
                        />
                    </Col>
                    <Col className="gutter-row padding" span={10}>
                        <Input
                            autoComplete="off"
                            label={"Time Horizon"}
                            name={"time"}
                            value={this.props.targetValue.timeHorizon}
                            onChange={(e) => this.props.handleChangeVal(e)}
                            floatingLabel={true}

                        />
                        {/* <Calendar /> */}
                    </Col>
                </Row>
                <Row gutter={32} className="business-initiative-block-main">
                    <Col className="gutter-row padding" span={14}>
                        <Input
                            autoComplete="off"
                            label={"Enter Business Initiative Name*"}
                            floatingLabel={true}
                            value={this.props.targetValue.goal}
                            onChange={(e) => this.props.handleChangeVal(e)}
                            name={"biName"}
                        />
                       
                    </Col>
                    <Col className="gutter-row padding" span={10}>
                        <p className="par">PEOPLE</p>
                    </Col>
                </Row>
                <Row gutter={32} className="business-initiative-block-main">
                    <Col className="gutter-row padding" span={14}>
                        <Input
                            autoComplete="off"
                            label={"Enter Objective and Metrics"}
                            floatingLabel={true}
                            value={this.props.targetValue.objectiveAndMetrics}
                            onChange={(e) => this.props.handleChangeVal(e)}
                            name={"objective"}
                        />
                    </Col>
                    <Col className="gutter-row padding" span={10}>
                        
                        <Input 
                            autoComplete="off"
                            label={"Enter Initiative Leader"}
                            floatingLabel={true}
                            value = {this.props.targetValue.initiativeLeader}
                            onChange = {(e)=>this.props.handleChangeVal(e)}
                            name = {"initiativeLeader"}
                        />
                    </Col>
                </Row>
                <Row gutter={32} className="business-initiative-block-main">
                    <Col className="gutter-row padding" span={14}>
                        {/* <Input
                            autoComplete="off"
                            label={"Enter Budget"}
                            floatingLabel={true}
                            value={this.props.targetValue.budget}
                            onChange={(e) => this.props.handleChangeVal(e)}
                            name={"budget"}
                            type="number"
                        />  */}
                        <InputITAlignment
                            autoComplete="off"
                            label={"Enter Budget"}
                            floatingLabel={true}
                            value={this.props.targetValue.budget}
                            onChange={(e) => this.props.handleChangeVal(e)}
                            name={"budget"}
                            type="number"
                            pattern="^([0-9]*)\.?([0-9]{1,2})?$"
                            max={10000000000000}
                        />
                       
                    </Col>
                    <Col className="gutter-row padding" span={10}>
                        
                        <Input 
                            autoComplete="off"
                            label={"Enter Executive Sponsor"}
                            floatingLabel={true}
                            value = {this.props.targetValue.executiveSponsor}
                            onChange = {(e)=>this.props.handleChangeVal(e)}
                            name = {"executiveSponser"}
                        />
                    </Col>
                </Row>
                <Row gutter={32} className="business-initiative-block-main">
                    <Col className="gutter-row padding" span={14}>
                        <p>Clear link to IT?</p>
                        <RadioGroup onChange={(e) => this.props.handleChangeVal(e)}
                            name={"linkStatus"}
                            value={this.props.targetValue.linkStatus}>
                            <Radio value={1}>Yes</Radio>
                            <Radio value={2}>No</Radio>
                        </RadioGroup>
                    </Col>
                </Row>

            </div>
        )
    }

}

BusinessInitiativeInput.propTypes = {
}

export default BusinessInitiativeInput;