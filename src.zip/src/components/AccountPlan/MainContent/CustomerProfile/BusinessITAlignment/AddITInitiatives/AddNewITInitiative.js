import React, { Component } from 'react';
import { Modal, Button} from 'antd';
// import './AddNewBusinessInitiative.scss';
import ItInitiativeInput from './ItInitiativeInput';
import axios from 'axios';
import Config from '../../../../../../config/Config';
import {message} from 'antd';
import DeletePopup from '../../../../../common/DeletePopup/DeletePopup';
const conf = new Config();


class AddNewITInitiative extends Component{
    constructor(props) {
        super(props);
        this.state = {
            itInitiativeId : this.props.itId,
            accountPlanId: this.props.accountPlanId,
            budget: "",
            businessInitiativeId: this.props.businessInitiativesId,
            executiveSponsor: "",
            goal: this.props.itGoal,
            initiativeLeader: "",
            initiativeName: "",
            linkStatus: 1,
            objectiveAndMetrics: "",
            timeHorizon: "",
            confirmDelete: false
        }
    }
      componentDidMount() {
        if(this.props.itId) {
            this.getItInitiatives(this.props.accountPlanId, this.props.itId);
        }
    }

    getItInitiatives = (accountPlanId,itInitiativeId)  => {
        let params = {
            method: conf.getBusinessGoals.method,
            url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/it?id="+itInitiativeId
        }
        const msg = message.loading("Loading IT initiative");
        axios(params).then(response => {
            if (response.status === 200) {
                this.setState({
                    budget: response.data.data.budget,
                    executiveSponsor: response.data.data.executiveSponsor,
                    goal: response.data.data.goal,
                    initiativeLeader: response.data.data.initiativeLeader,
                    initiativeName: response.data.data.initiativeName,
                    linkStatus: response.data.data.linkStatus,
                    objectiveAndMetrics: response.data.data.objectiveAndMetrics,
                    timeHorizon: response.data.data.timeHorizon
                });
                msg();
            }
            else{
                message.error('Error in fetching IT Initiatives.');
            }
        });
    }

    handleChange = (e) =>{
        switch(e.target.name){
            case "itName": {
                this.setState({goal : e.target.value});
                break;
            }
            case "time": {
                this.setState({timeHorizon : e.target.value});
                break;
            }
            case "objective": {
                this.setState({objectiveAndMetrics : e.target.value});
                break;
            }
            case "initiativeLeader": {
                this.setState({initiativeLeader : e.target.value});
                break;
            }
            case "budget": {
                this.setState({budget : e.target.value});
                break;
            }
            case "executiveSponser": {
                this.setState({executiveSponsor : e.target.value});
                break;
            }
            case "linkStatus": {
                this.setState({linkStatus : e.target.value});
                break;
            }
            default:{
                break;
            }
        }
    }
    ConfHandleCancel = () => {
        this.setState({confirmDelete : false});
    }
    validateForm() {
        if(this.state.goal != "") {
            this.props.handleSave(
                this.state,
                this.props.itId === undefined || this.props.itId === null || !this.props.itId ? 'create' : 'update'
            );
        }
    }
    render = () =>{
        let deleteBtn;
        if (this.props.itId != null){
            deleteBtn = <Button key="delete" type="danger"onClick={() => this.setState({ confirmDelete: true })}>Delete</Button>
        }
        return (
            <div className="add-edit-new-group">
            {this.props.visible && <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    deleteBtn ,
                    <Button key="submit" type="primary" onClick={()=>this.validateForm()}>
                        Save
                    </Button>,
                ]}
            >
                <ItInitiativeInput
                    businessGoalInput = {this.props.businessGoalInput}                    
                    actions = {this.props.actions}
                    handleChangeVal = {(e)=>this.handleChange(e)}
                    targetValue = {this.state}
                />
            </Modal>}

            {this.state.confirmDelete && 
                <DeletePopup 
                    heading="Delete IT initiative"
                    visible={this.state.confirmDelete} 
                    ok={()=>this.props.handleDelete(this.state)} 
                    cancel={()=>this.ConfHandleCancel()} 
                    okText="Yes delete it" 
                    cancelText="No, cancel it" 
                    contents="Are you sure you want to delete the IT Initative ?" 
                />
            }
        </div>
        )
    }

}

AddNewITInitiative.propTypes = {
}

export default AddNewITInitiative;