import React from 'react';
import { Icon} from 'antd'; //Input
export const taggedUser = (props) =>{
    return (
        <div className="popover-cont">
            <div>
                <sapn>John Smith</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Megan Cole</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Ruby Dasmond</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
        </div>
    )
}