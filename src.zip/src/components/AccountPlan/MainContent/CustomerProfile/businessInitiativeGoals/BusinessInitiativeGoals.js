import React, { Component } from 'react';
import { Icon, Popover, Collapse } from 'antd'; //Input
import { taggedUser } from '../taggedUser/taggedUser';
import VmFloatingInput from '../../../../common/VmFloatingInput/VmFloatingInput';
import PropTypes from "prop-types";
import {cloneDeep} from 'lodash';
import VmTextareaMaterial from '../../../../common/VmTextarea/VmTextareaMaterial';
import {atleastOne} from '../../../../../Services/Validate';

const Panel = Collapse.Panel;

class BusinessInitiativeGoals extends Component {
    componentDidMount(){
        this.props.actions.fetchGoals(this.props.accountPlanId);
    }

    selectChange(e,index){
        let newGoal = cloneDeep(this.props.goals);
        newGoal[index].goalValue = e.target.value;
        this.props.actions.updateGoal(newGoal);
    }   
    update(){
        this.props.actions.updateGoalAPI(this.props.goals);
    }
    deleteGoal(index,goal){
        let newGoal = cloneDeep(this.props.goals);
        newGoal.splice(index,1);
        this.props.actions.deleteGoal(
            goal,
            this.props.actions.updateGoal(newGoal)
        );
    }
    render = () => {
        return (
            // defaultActiveKey={['5']}
            <Collapse className="collapse-margin collapse-bi-goals">
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Business Initiatives (Goals)</span>
                    <span className="red-star">*</span>
                    {/* <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span> */}
                    {/* <Popover placement="leftTop" content={taggedUser()} title="Currently Tagged:">
                        <span className="info-icon">
                            <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                        </span>
                    </Popover> */}
                </div>} key="5">
                    {
                        this.props.goals.length === 0 ? <div className="no-value">No Business Initiatives (Goals)</div> : ""
                    }
                    {
                        this.props.goals.map((goal,index)=>(
                            <div key={index}>
                                <div className="width-97" style={{padding:'0 0 0 4px'}}>
                                    <VmTextareaMaterial
                                        index={index}
                                        value={goal.goalValue}
                                        placeholder="Please enter goal"
                                        title={"Goal " + (index +1)}
                                        onChange={(e)=>this.selectChange(e,index)}
                                        onBlur={this.update.bind(this)}
                                        maxLength="5000"
                                    />
                                </div>
                                <div className="width-3" style={{marginTop:18}} onClick={()=>this.deleteGoal(index,goal)}>
                                    <Icon className="minus-circle" type="minus-circle-o" />
                                </div>
                                
                            </div>
                        ))
                    }
                    {/* style={{margin:'4px 65px 10px 0px'}} */}
                    <div className="pull-right margin-horizontal"  onClick={()=>this.props.actions.pushGoal(this.props.accountPlanId)}>
                        <Icon type="plus" style={{ color: '#007cbb', fontSize: "10px", fontWeight: 'bold' }} />
                        <button className="add-btn">ADD GOAL</button>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12" style={{}}>
                        {  !atleastOne(this.props.goals,'goalValue') &&
                            <div className="pull-right reqrd-txt">
                                <Icon type="warning" style={{ color: '#ff153f' }} />
                                <span className="required-txt">Text fields incomplete!</span>
                            </div>
                        }
                    </div>
                </Panel>
            </Collapse>
        )
    }
}

BusinessInitiativeGoals.propTypes = {
    goals: PropTypes.array.isRequired,
    accountPlanId: PropTypes.string.isRequired,
    actions: PropTypes.object
}

export default BusinessInitiativeGoals;