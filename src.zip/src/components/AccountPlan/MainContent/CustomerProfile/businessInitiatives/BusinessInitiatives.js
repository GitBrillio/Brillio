import React, { Component } from 'react';
import { Icon, Popover, Collapse } from 'antd'; //Input
import VmFloatingInput from '../../../../common/VmFloatingInput/VmFloatingInput';
import { taggedUser } from '../taggedUser/taggedUser';
import PropTypes from "prop-types";
import { cloneDeep } from 'lodash';
import VmTextareaMaterial from '../../../../common/VmTextarea/VmTextareaMaterial';
import {atleastOne} from '../../../../../Services/Validate';

//import Textarea from 'muicss/lib/react/textarea';


const Panel = Collapse.Panel;


class BusinessInitiatives extends Component {

    componentDidMount(){
        this.props.actions.fetchIssues(this.props.accountPlanId);
    }

    selectChange(e,index){
        let newIssues = cloneDeep(this.props.issues);
        newIssues[index].issueValue = e.target.value;
        this.props.actions.updateIssue(newIssues);
    }   
    update(){
        this.props.actions.updateIssueAPI(this.props.issues);
    }
    deleteIssue(index,issue){
        let newIssues = cloneDeep(this.props.issues);
        newIssues.splice(index,1);
        this.props.actions.deleteIssue(
            issue,
            this.props.actions.updateIssue(newIssues)
        );
    }
    render = () => {
        return (
            // defaultActiveKey={['4']}
            <Collapse className="collapse-margin collapse-bi-issues" >
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Business Initiatives (Issues)</span>
                    <span className="red-star">*</span>
                    {/* <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span> */}
                    {/* <Popover placement="leftTop" content={taggedUser()} title="Currently Tagged:">
                        <span className="info-icon">
                            <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                        </span>
                    </Popover> */}
                </div>} key="4">
                {
                    this.props.issues.length === 0 ? <div className="no-value">No Business Initiatives (Issues)</div> : ""
                }
                {
                        this.props.issues.map((issue,index)=>(
                            <div key={index}>
                                <div className="width-97" style={{padding:'0 0 0 4px'}}>
                                    
                                    <VmTextareaMaterial 
                                        index={index}
                                        value={issue.issueValue}
                                        title={"Issue " + (index +1)}
                                        onChange={(e)=>this.selectChange(e,index)}
                                        onBlur={this.update.bind(this)}
                                        maxLength="5000"
                                        placeholder="Please enter Issue"
                                    />
                                    
                                </div>
                                <div className="width-3" style={{marginTop:18}} onClick={()=>this.deleteIssue(index,issue)}>
                                    <Icon className="minus-circle" type="minus-circle-o" />
                                </div>
                                
                            </div>
                        ))
                    }
                    <div className="pull-right margin-horizontal"  onClick={()=>this.props.actions.pushIssue(this.props.accountPlanId)}>
                        <Icon type="plus" style={{ color: '#007cbb', fontSize: "10px", fontWeight: 'bold' }} />
                        <button className="add-btn">ADD ISSUE</button>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12" style={{}}>
                        {  !atleastOne(this.props.issues,'issueValue') &&
                            <div className="pull-right reqrd-txt">
                                <Icon type="warning" style={{ color: '#ff153f' }} />
                                <span className="required-txt">Text fields incomplete!</span>
                            </div>
                        }
                    </div>
                    
                </Panel>
            </Collapse>

        )
    }
}

BusinessInitiatives.propTypes = {
    issues: PropTypes.array.isRequired,
    accountPlanId: PropTypes.string.isRequired,
    actions: PropTypes.object
}

export default BusinessInitiatives;