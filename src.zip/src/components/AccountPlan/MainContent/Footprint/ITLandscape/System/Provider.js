import React from 'react';
import Input from 'muicss/lib/react/input';
import remove from '../../../../../../images/remove.svg';


export const Provider = ({ provider,deleteProvider,systemIndex,providerIndex,type,actions,updateSystem }) => {
    return (
        <div>
            
            <div className="col-lg-6" style={{ paddingLeft: 0 }}>
                <Input 
                    label="Platform"
                    value={provider.providerName} 
                    onChange={(e)=>actions.changeProvider(e.target.value,systemIndex,providerIndex,type,'providerName')} 
                    onBlur={updateSystem}
                    floatingLabel={true} 
                />
            </div>
            <div className="col-lg-5">
                <Input
                    label="Platform Provider" 
                    floatingLabel={true} 
                    onChange={(e)=>actions.changeProvider(e.target.value,systemIndex,providerIndex,type,'providerPlatform')} 
                    value={provider.providerPlatform} 
                    onBlur={updateSystem}
                />
            </div>
            
            <div className="col-lg-1 delete-icon plr0">
                <img 
                    src={remove} title="Remove provider" 
                    onClick={()=>deleteProvider(provider,type,systemIndex,providerIndex)} 
                    className="remove-provider" 
                    alt="Delete Provider" 
                />
            </div>
        </div>
    )
}