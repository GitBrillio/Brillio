import React, { Component } from 'react';
import Input from 'muicss/lib/react/input';
import './data-points.scss';
import PropTypes from 'prop-types';

export default class DataPoints extends Component{
    render(){
        const {point,actions,accountPlanId} = this.props
        return(
            <div className="data-points">
                <div className="headers">
                    Key Data Points
                </div>
                { point ? 
                <div className="body-port">
                    <div className="heading">
                        <a target="_blank" href={"https://test.salesforce.com/"+this.props.point.accountId}>Go to VMstar</a>
                    </div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('itSpendAmount',e.target.value)} 
                                label="ANNUAL IT SPEND" 
                                floatingLabel={true} 
                                value={point.itSpend} 
                            />
                        </div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('noOfVms',e.target.value)} 
                                label="# VMS" 
                                floatingLabel={true} 
                                value={point.noOfVms} 
                            />
                        </div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('noOfVirtualHosts',e.target.value)}
                                label="# VIRTUAL HOSTS (ESX, HYPERV)" 
                                floatingLabel={true} 
                                value={point.noOfVirtualHosts} 
                            />
                        </div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('noOfUnvirtualizedX86Servers',e.target.value)}
                                label="# X86 SERVERS NOT VIRTUALIZED" 
                                floatingLabel={true} 
                                value={point.noOfx86ServersNotVirtualized} 
                            />
                        </div>
                        <div className="input-box">
                            <Input
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)} 
                                //onChange={(e)=>actions.updatePointField('noOfDesktops',e.target.value)}
                                label="# DESKTOPS" 
                                floatingLabel={true} 
                                value={point.noOfDesktops} 
                            />
                        </div>
                        
                        <div className="input-box">
                            <Input 
                                label="% DESKTOPS VIRTUALIZED" 
                                floatingLabel={true} 
                                value={point.desktopsVirtualizedPercent} 
                            />
                        </div>
                        <div className="input-box">
                            <Input
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)} 
                                label="# MOBILE DEVICES" 
                                //onChange={(e)=>actions.updatePointField('noOfMobileDevices',e.target.value)}
                                floatingLabel={true} 
                                value={point.noOfMobileDevices} 
                            />
                        </div>
                        <div className="input-box">
                            <Input
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)} 
                                label="% MOBILE DEVICES MANAGED" 
                                //onChange={(e)=>actions.updatePointField('noOfMobileDevices',e.target.value)}
                                floatingLabel={true} 
                                value={point.mobileDevicesManagedPercent} 
                            />
                        </div>
                    </div>
                    :
                        <div style={{textAlign:'center',marginTop:'45px'}}>No Account Profile found in VMstar</div>
                }
                
            </div>
        )
    }
}
DataPoints.propTypes = {
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    point: PropTypes.any
}
