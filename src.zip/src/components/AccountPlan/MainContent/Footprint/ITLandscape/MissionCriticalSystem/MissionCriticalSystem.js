import React, { Component } from 'react';
import { Collapse, Button,Row,Col } from 'antd'; //Input
import PropTypes from 'prop-types';
import System from '../System/System';
import './mci.scss';
import DeletePopup from '../../../../../common/DeletePopup/DeletePopup';
const Panel = Collapse.Panel;

class MissionCriticalSystem extends Component{


    state = {
        deletePopup: false,
        type: null,
        systemIndex: null,
        system: null
    }

    deleteCancel(){
        this.setState({
            deletePopup: false
        })
    }

    deleteSystem(type,systemIndex,system){
        this.setState({
            deletePopup: true,
            type: type,
            systemIndex: systemIndex,
            system: system
        })
    }

    deleteOk(){
        this.props.actions.deleteSystem(
            this.props.accountPlanId,
            this.state.system,
            this.state.systemIndex,
            this.state.type,
            this.deleteCancel.bind(this)
        );
    }

    
    render(){
        const {footprint,actions,accountPlanId} = this.props;
        return(
            <Collapse defaultActiveKey={['1']} className="mci">
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Mission Critical Systems</span>
                </div>} key="1">
                    <section>
                            {
                                footprint.missionCriticalSystems.length === 0 ?
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-30 text-center">
                                    <Button onClick={()=>actions.pushSystem(accountPlanId,'MISSION_CRITICAL_SYSTEM')} className="dashed-button" type="dashed">Create Mission Critical System</Button>
                                </div>
                                :
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-15">
                                    <Button onClick={()=>actions.pushSystem(accountPlanId,'MISSION_CRITICAL_SYSTEM')} style={{height:'40px'}} type="dashed" block>Create New Mission Critical System</Button>
                                    <Row className="system-area" gutter={12}>
                                        {
                                            footprint.missionCriticalSystems.map((obj,index)=>(
                                               <Col key={index} span={12} style={{marginTop:'15px'}}>
                                                    <System 
                                                        system={obj} 
                                                        actions={actions} 
                                                        type="MISSION_CRITICAL_SYSTEM"
                                                        key={index} 
                                                        systemIndex={index}
                                                        deleteSystem={this.deleteSystem.bind(this)}
                                                    />
                                                </Col>
                                            ))
                                        }
                                    </Row>
                                </div>
                            }
                             <DeletePopup 
                                heading="Delete Mission Critical System"
                                visible={this.state.deletePopup} 
                                ok={()=>this.deleteOk()} 
                                cancel={()=>this.deleteCancel()} 
                                okText="Yes delete it" 
                                cancelText="No, cancel it" 
                                contents="Are you sure you want to delete the Mission Critical System?" 
                            /> 
                    </section>
                </Panel>
            </Collapse>
                    
        )
    }
}

MissionCriticalSystem.propTypes = {
    actions: PropTypes.object,
    footprint: PropTypes.object,
    accountPlanId: PropTypes.string
}


export default MissionCriticalSystem;