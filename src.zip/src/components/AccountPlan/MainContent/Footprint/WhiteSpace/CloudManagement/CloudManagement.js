import React, { Component } from "react";
import { Layout, Icon, Collapse } from "antd";
import "./cloud-management.scss";
import PropTypes from "prop-types";
import FWHeader from './../Header/FWHeader';
import FWComponents from './../EndUserComputing/FWComponents';


const Panel = Collapse.Panel;

class CloudManagement extends Component {
  constructor(props) {
    super(props);
    this.state = {
        header: {
          title: "Cloud Management",
          revenue: "$14M",
          booking: "Bookings FY18",
          infoIcon: {
            title: "Cloud Management Title",
            content: "Cloud Management Content"
          },
          timestamp: {
            title: "Last Updated",
            author: "John Smith",
            date: "Aug 11 2017"
          }
        }
      };
  }

  render() {
    const {items, status} = this.props.footprint.footPrintAndWhiteSpace;
    let endUserComputingProducts = [];
    let footprintWhitespaceId = null;
    if(typeof items !== 'undefined' && items.length > 0){
       endUserComputingProducts = items[1].products;
       footprintWhitespaceId = items[1].footprintWhitespaceId
    }
    return (
        <Collapse className="euc">
        <Panel header={<FWHeader headerInfo={this.state.header} />} key="1">
          <section>
            <div className="iot-wrapper">
              {endUserComputingProducts.map((product, i) => {
                let productDeploymentStatus = status.filter(statusObj => statusObj.deploymentStatusId === product.deploymentStatusId);
                let productStatus = productDeploymentStatus[0];
                return <FWComponents 
                product={product} 
                key={i}
                status={productStatus}
                accountPlanId={this.props.accountPlanId}
                statusMenu={status}
                footprintWhitespaceId={footprintWhitespaceId}
                actions={this.props.actions}
                />;
              })}
            </div>
          </section>
        </Panel>
      </Collapse>
    )
  }
}

CloudManagement.propTypes = {
    actions: PropTypes.object,
    footprintReducer: PropTypes.object,
    accountPlanId: PropTypes.string
}

CloudManagement.defaultProps = {
    actions: {},
    footprintReducer: {},
    accountPlanId: ""
}


export default CloudManagement;
