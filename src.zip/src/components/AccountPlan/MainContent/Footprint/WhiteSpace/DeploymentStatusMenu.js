import React, { Component } from "react";
import { Menu, Dropdown, Icon, Popover, Button, Layout, Collapse } from "antd";
import "./EndUserComputing/end-user-computing.scss";
import PropTypes from "prop-types";
import { isEmpty } from "lodash";
import { Select, Divider } from "antd";


const DeploymentStatusMenu = (props) => {
    return (
        <Menu className="deployment-status-menu"
        onClick={props.menuChange}
        >
          <span className="deployment-status-header">Deployment Status</span>
          <Menu.Item key="0" className="test">
            <div className="deployment-status-wrapper">
              <span className="deployment-status-selector-1" />
              <span className="title-status-1">Fully Deployed</span>
              <span className="subtitle-status">
                Purchased and deployed across entire infrastructure or user base
              </span>
            </div>
          </Menu.Item>
          <Menu.Item key="1">
            <div>
              <span className="deployment-status-selector-2" />
              <span className="title-status-2">Partially Deployed</span>
              <span className="subtitle-status">
                Purchased and/or deployed partially, ie. not yet across entire
                infrastructure or user base
              </span>
            </div>
          </Menu.Item>
          <Menu.Item key="2">
            <div>
              <span className="deployment-status-selector-3" />
              <span className="title-status-3">Active Campaign</span>
              <span className="subtitle-status">
                Validated SFDC opportunity or close to it
              </span>
            </div>
          </Menu.Item>
          <Menu.Item key="3">
            <div>
              <span className="deployment-status-selector-4" />
              <span className="title-status-4">Shelfware</span>
              <span className="subtitle-status">Purchased but not deployed</span>
            </div>
          </Menu.Item>
          <Menu.Item key="4">
            <div>
              <span className="deployment-status-selector-5" />
              <span className="title-status-5">Competitive Loss</span>
              <span className="subtitle-status">
                Validated SFDC opportunity or close to it
              </span>
            </div>
          </Menu.Item>
          <Menu.Item key="5">
            <div>
              <span className="deployment-status-selector-6" />
              <span className="title-status-6">White Space</span>
              <span className="subtitle-status">
                Validated SFDC opportunity or close to it
              </span>
            </div>
          </Menu.Item>
          <div className="no-status-btn">
            <Button>No Status</Button>
          </div>
        </Menu>
    )
}

DeploymentStatusMenu.propTypes = {
    statusMenu: PropTypes.array
}

export default DeploymentStatusMenu

