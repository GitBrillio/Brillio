import React, { Component } from "react";
import { Icon, Popover, Button, Layout, Collapse } from "antd";
import "./end-user-computing.scss";
import PropTypes from "prop-types";
import FWHeader from "../Header/FWHeader";
import FWComponents from "./FWComponents";

const Panel = Collapse.Panel;

class EndUserComputing extends Component {
  constructor(props) {
    super(props);
    this.state = {
      header: {
        title: "End User Computing and IoT",
        revenue: "$14M",
        booking: "Bookings FY18",
        infoIcon: {
          title: "End User Computing Title",
          content: "End User Content"
        },
        timestamp: {
          title: "Last Updated",
          author: "John Smith",
          date: "Aug 11 2017"
        }
      }
    };
  }
  render() {
    const {items, status} = this.props.footprint.footPrintAndWhiteSpace;
    let endUserComputingProducts = [];
    let footprintWhitespaceId = null;
    if(typeof items !== 'undefined' && items.length > 0){
       endUserComputingProducts = items[0].products;
       footprintWhitespaceId = items[0].footprintWhitespaceId
    }
    return (
      <Collapse defaultActiveKey={["1"]} className="euc">
        <Panel header={<FWHeader headerInfo={this.state.header} />} key="1">
          <section>
            <div className="iot-wrapper">
              {endUserComputingProducts.map((product, i) => {
                let productDeploymentStatus = status.filter(statusObj => statusObj.deploymentStatusId === product.deploymentStatusId);
                let productStatus = productDeploymentStatus[0];
                return <FWComponents 
                product={product}
                key={i}
                accountPlanId={this.props.accountPlanId}
                status={productStatus}
                footprintWhitespaceId={footprintWhitespaceId}
                statusMenu={status}
                actions={this.props.actions}
                />;
              })}
            </div>
          </section>
        </Panel>
      </Collapse>
    );
  }
}

EndUserComputing.propTypes = {
  actions: PropTypes.object,
  footprint: PropTypes.object,
  accountPlanId: PropTypes.string
};

EndUserComputing.defaultProps = {
  actions: {},
  footprint: {},
  accountPlanId: ""
};

export default EndUserComputing;
