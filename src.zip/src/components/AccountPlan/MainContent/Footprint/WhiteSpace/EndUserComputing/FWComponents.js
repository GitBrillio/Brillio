import React, { Component } from "react";
import { Menu, Dropdown, Icon, Popover, Button, Layout, Collapse } from "antd";
import "./end-user-computing.scss";
import PropTypes from "prop-types";
import { isEmpty } from "lodash";
import { Select, Divider } from "antd";
import DeploymentStatusMenu from "./../DeploymentStatusMenu";
import _ from 'underscore';

const { Option } = Select;

class FWComponents extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentStatus: "",
      menuVisible: false,
      dropdownVisible: false,
      menuClassName: ""
    };
  }

  menuChange = e => {
    let menuClassName = e
      .split(" ")
      .join("-")
      .toLowerCase();
    this.setState({ currentStatus: e, menuClassName });
    this.update(e)
  };

  update(menuStr){
    let deploymentStatusId = _.find(this.props.statusMenu,(o)=>{
      return o.statusLabel === menuStr
    });
    this.props.actions.updateFootprint({
      productLookupId: this.props.product.productLookupId,
      deploymentStatusId: deploymentStatusId === undefined ? null : deploymentStatusId.deploymentStatusId,
      footprintId: this.props.footprintWhitespaceId
    },this.props.accountPlanId);
  }

  showStatusMenu = e => {
    this.setState({
      dropdownVisible: true
    });
  };

  getColorById(name){
    switch(name){
      case 'Fully Deployed': 
        return "#0A8400";
      case 'Partially Deployed': 
        return "#2880DC";
      case 'Active Campaign':
        return "#D6089E";
      case 'Shelfware':
        return "#FFA416";
      case 'Competitive Loss':
        return "#FE3333";
      case 'White Space':
        return "#222222";
      default:
        return "#000";
    }
  }
  componentDidMount() {
    let currentStatus = isEmpty(this.props.status)
      ? "No Status"
      : this.props.status.statusLabel;
    let menuClassName = currentStatus
      .split(" ")
      .join("-")
      .toLowerCase();
    this.setState({
      currentStatus,
      menuClassName
    });
  }

  render() {
    const { product, status, statusMenu } = this.props;
    const dropdownStyle = {
      width: "400px"
    };
    if (isEmpty(status)) {
      status.statusLabel = "No Status";
    }
    return (
      <div className={"iot-element " + this.state.menuClassName}>
        {product.productLabel}
        <Select
          defaultValue={this.state.currentStatus}
          style={{ width: "min-content" }}
          onChange={(e)=>this.menuChange(e)}
          dropdownMatchSelectWidth={false}
          // open={true}
          getPopupContainer={node => node.parentNode}
          // dropdownMenuStyle={dropdownStyle}
          dropdownStyle={dropdownStyle}
          value={this.state.currentStatus}
          onDropdownVisibleChange={this.showStatusMenu}
        >
          <Option className="deployment-status-header" value="Deployment Status" disabled={true}>Deployment Status</Option>
          {statusMenu.map((statusObj, i) => {
            return (
              <Option key={i} value={statusObj.statusLabel} className="option-tab" style={{color: statusObj.statusColor}}>
                <div
                  className="deployment-status-wrapper"
                  style={{ cursor: "pointer" }}
                >
                  {
                    <span
                      className="deployment-status-selector-1"
                      style={{ background: this.getColorById(statusObj.statusLabel) }}
                    />
                  }
                  <span className="title-status">{statusObj.statusLabel}</span>
                  {
                    <span className="subtitle-status">
                      {statusObj.statusDescription}
                    </span>
                  }
                </div>
              </Option>
            );
          })}
          <Option className="no-status-btn" value="No Status">
            No Status
          </Option>
        </Select>
      </div>
    );
  }
}

FWComponents.propTypes = {
  product: PropTypes.object,
  status: PropTypes.object,
  statusMenu: PropTypes.array,
  footprintWhitespaceId: PropTypes.string
};

FWComponents.defaultProps = {
  product: {},
  status: {},
  statusMenu: []
};
export default FWComponents;
