import React, { Component } from "react";
import { Icon, Popover, Button, Layout, Collapse } from "antd";
import "./fw-header.scss";
import PropTypes from "prop-types";

class FWHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { headerInfo } = this.props
    return (
      <div className="row">
        <div className="header-title">
          <span className="collapse-header">{headerInfo.title}</span>
        </div>
        {/* <div className="header-revenue">
          <span>{headerInfo.revenue}</span><span>{headerInfo.booking}</span>
        </div>
        <div className="header-timestamp">
          <span>{headerInfo.timestamp.title}</span>
          <span>by {headerInfo.timestamp.author} on {headerInfo.timestamp.date}</span>
        </div>
        <div className="header-info-icon">
          <Popover placement="leftTop" content={headerInfo.infoIcon.content} title={headerInfo.infoIcon.title}>
            <span>
              <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
            </span>
          </Popover>
        </div> */}
      </div>
    );
  }
}

FWHeader.propTypes = {
  headerInfo: PropTypes.object
}

FWHeader.defaultProps = {
  headerInfo: {}
}

export default FWHeader;
