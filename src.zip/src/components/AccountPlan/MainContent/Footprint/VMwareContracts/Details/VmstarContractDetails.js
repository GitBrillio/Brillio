import React,{Component} from 'react';
import './details.scss';
import arrow  from './arrow-key.png';
import { Row, Col, Icon} from 'antd';
import Input from 'muicss/lib/react/input';
import PropTypes from 'prop-types';
import { CheckedboxLabelDataArray } from '../../../../../../Services/CheckboxData';

class VmstarContractDetails extends Component{
    state = {
        renewalClick:false,
        scopeFieldEdited:false
    }
    // componentWillMount() {
    //     window.addEventListener("click", this.handleClickOutside.bind(this));
    //   }
    
    // componentWillUnmount() {
    //     window.removeEventListener("click", this.handleClickOutside.bind(this));
    // }
    // handleClickOutside(e) {
    //     let data;
    //     data = {
    //         accountPlanId: this.props.accountPlanId ,
    //         sfdcCustomerId:"CUST-0002424795",
    //         sfdcOpportunityId:this.props.vmstarContractData.sfdcOpportunityId , 
    //         opportunityScope : this.props.vmstarContractData.opportunityScope
    //     }
    //     if (
    //       !e.target.closest(".scope-body-vmstar-details")
    //     ) {
    //         this.state.scopeFieldEdited ?
    //             this.props.actions.hanascopeUpdate(data)
    //         :
    //             this.setState({
    //                 scopeFieldEdited: false
    //             });
    //     }
    // }
    render(){
        const {vmstarContractData,index} = this.props;
        return(
                <div className="details-cont">
                    <section className="details-sec">
                        <Row className="div-style">
                            <p className="para-style">{vmstarContractData.opportunityNumber} <img src={arrow}/></p>                             
                        </Row>
                        <Row className ="details-body">
                            <Col span={13} className="padding0">
                                <p className="heading-style">Opportunity Name</p>
                                <p className="regular-font">{vmstarContractData.opportunityName}</p>
                            </Col>
                            <Col span={4} className="align-right padding0">
                                <p className="heading-style">Status</p>
                                <p className="regular-font">{vmstarContractData.status}</p>
                            </Col>
                            <Col span={5} className="align-right padding0">
                                <p className="heading-style">Contract Period</p>
                                <p className="regular-font">{vmstarContractData.contractStartDate + ' - ' +vmstarContractData.contractEndDate}</p>
                            </Col>
                            <Col span={2} className="align-right padding0">
                                <p className="heading-style">ELA</p>
                                <p className="regular-font">{vmstarContractData.ela}</p>
                            </Col>
                        </Row>
                        <Row className="product-main">
                                <div className="left-product">
                                    <p className="heading-style">Products</p>
                                    <div className="product-list">
                                    {
                                        vmstarContractData.productPlatform && CheckedboxLabelDataArray(vmstarContractData.productPlatform).map((val,idx)=>(
                                            <span key={idx}>{val}</span>
                                        ))
                                    }
                                    </div>
                                </div>
                                <div className="right-product">
                                    <span>Deal Value: </span>
                                    <span className="semi-bold-font"> $ {vmstarContractData.opportunityAmount}</span>
                                </div>
                        </Row>
                        <Row className="add-scope">
                            {
                                this.state.renewalClick || vmstarContractData.opportunityScope ?
                                <div className="scope-body-vmstar-details">
                                    <Input 
                                        label={"Scope of Renewal Opportunity"}
                                        floatingLabel={true} 
                                        value = {vmstarContractData.opportunityScope}
                                        onChange = {
                                            (e)=>{
                                                this.props.onChangeScope(e.target.value,index);
                                            }
                                        }
                                        onBlur = {
                                            this.props.actions.hanascopeUpdate({
                                                        accountPlanId: this.props.accountPlanId ,
                                                        sfdcCustomerId:"CUST-0002424795",
                                                        sfdcOpportunityId:this.props.vmstarContractData.sfdcOpportunityId , 
                                                        opportunityScope : this.props.vmstarContractData.opportunityScope
                                                    })
                                        }
                                    />
                                    <div className="delete-icon" onClick={()=>
                                        {
                                            this.setState({renewalClick:false});
                                            this.props.actions.hanascopeUpdate({
                                                accountPlanId: this.props.accountPlanId ,
                                                sfdcCustomerId:"CUST-0002424795",
                                                sfdcOpportunityId:this.props.vmstarContractData.sfdcOpportunityId , 
                                                opportunityScope : ""
                                            })
                                        }
                                        
                                
                                    }>
                                        <Icon className="minus-circle" type="minus-circle-o" />
                                    </div> 
                                </div>
                                :
                                <button onClick={()=>this.setState({renewalClick:true})}>+ Add Scope of Renewal Opportunity</button>
                            }
                        </Row>
                    </section>
                </div>
                
        )
    }
}
VmstarContractDetails.propTypes = {
    actions:PropTypes.object,
    accountPlanId: PropTypes.string,
    index: PropTypes.number,
    vmstarContractData :PropTypes.object,
    vmstarReducer :PropTypes.object,
    onChangeScope: PropTypes.func
}

export default VmstarContractDetails;