import React, { Component } from 'react';
import { Layout} from 'antd';
import PropTypes from 'prop-types';
import './VMware-contracts.scss';
const { Content } = Layout;
import CustomContracts from "./CustomContracts/CustomContracts";
import VmstarContracts from "./VmstarContracts/VmstarContracts";

class VMwareContracts extends Component{
    componentDidMount(){
        this.props.actions.getCustomContracts(this.props.accountPlanId);
        this.props.actions.getProducts();
        this.props.actions.getStatus();
    }
    render = () =>{
        const {accountPlanId,actions,footprintReducer,account} = this.props;
        return (
            <section className="vmware-contracts">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3 className="h3-style">Footprint</h3>
                        <h1>VMware Contracts</h1>
                            <CustomContracts 
                                actions={actions}
                                customContactsReducer = {footprintReducer.vmwareContracts}
                                accountPlanId = {accountPlanId}
                            />
                            <VmstarContracts 
                                actions={actions}
                                vmstarReducer = {footprintReducer.vmwareContracts}
                                accountPlanId = {accountPlanId}
                                account = {account}
                            />
                    </Content>
                </Layout>
            </section>
        )
    }
}

VMwareContracts.propTypes = {
  actions: PropTypes.object,
  accountPlanId: PropTypes.string,
  footprintReducer: PropTypes.object,
  account: PropTypes.object
}

export default VMwareContracts;
