import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button} from 'antd';
import './contract-modal.scss';
import ContractModalBlock from './ContractModalBlock/ContractModalBlock';

class ContractModal extends Component {
    render = () => {
        const { visible,heading,okText,handleCancel} = this.props
      
        return (
            <div className="contract-modal-main">
                    <Modal
                        className="contract-modal"
                        title={heading}
                        visible={visible}
                        centered
                        onCancel={handleCancel}
                        footer={[
                            <Button key="submit" className="pull-right" type="primary" onClick={this.props.create}>
                                {okText} 
                            </Button>
                        ]}
                    >
                        <ContractModalBlock 
                            actions={this.props.actions} 
                            customContactsReducer ={this.props.customContactsReducer}
                            accountPlanId={this.props.accountPlanId}
                        />
                    </Modal>
                
                
        </div>)
    }
}

ContractModal.propTypes = {
    actions: PropTypes.object,
    customContactsReducer:PropTypes.object,
    visible: PropTypes.bool.isRequired,
    heading:PropTypes.string,
    okText: PropTypes.string,  
    handleCancel: PropTypes.func,
    create: PropTypes.any,
    accountPlanId: PropTypes.string,
    clickedDetailsData: PropTypes.object,
    index: PropTypes.number
}

export default ContractModal;
