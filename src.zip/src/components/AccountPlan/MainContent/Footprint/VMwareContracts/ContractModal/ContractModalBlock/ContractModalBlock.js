import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Row, Col,Icon,DatePicker, Select } from 'antd';
const { RangePicker } = DatePicker;
import Input from 'muicss/lib/react/input';
import './contract-modal-block.scss';
import { CheckboxDataArray,CheckedboxLabelDataString } from "../../../.././../../../Services/CheckboxData";
import CustomDropdown from "../../../../../../common/customDropdown/CustomDropdown";
import {cloneDeep} from 'lodash';
const Option = Select.Option;

var products=['VCPP','COMPUTE','STORAGE & AVAILABILITY','DESKTOP','EMERGING SOLUTIONS','VMC ON AWS','MOBILE','NETWORK & SECURITY','VERTUALIZE MANAGEMENT','WORKSPACE ONE','SDDC SOLUTIONS','PREMIER SERVICES','CLOUD NATIVE APPS','SERVICES','Others'];

class ContractModalBlock extends Component {
    state={
        dropdownProduct: CheckboxDataArray(products),
        labelsProduct:[],
        status: {  
            "data":[  
               {  
                  "lookUpId":68,
                  "value":"01 - Not Contacted"
               },
               {  
                  "lookUpId":69,
                  "value":"02 - Contacted"
               },
               {  
                  "lookUpId":70,
                  "value":"03 - Quoted"
               },
               {  
                  "lookUpId":71,
                  "value":"04 - Negotiate"
               },
               {  
                  "lookUpId":72,
                  "value":"05 - Agreement to Purchase"
               },
               {  
                  "lookUpId":73,
                  "value":"06 - Closed Won"
               },
               {  
                  "lookUpId":74,
                  "value":"07 - Closed Lost"
               }
            ]
         },
         renewalClick:false
    }

    onChangeCheckbox(e,i,val){
        let checkedBox = cloneDeep(val);
        checkedBox[i].status = e.target.checked;
        this.setState({ dropdownProduct: checkedBox });
        this.setState({ labelsProduct : CheckedboxLabelDataString(checkedBox)});
        this.props.actions.changeCustomContractModalFields("products",CheckedboxLabelDataString(checkedBox))
    }
    render = () => {
        const {customContactsReducer,actions,accountPlanId} = this.props;
        return (
            <div>
           {this.props.customContactsReducer &&  <div className="contract-modal-block-main">
            <Row gutter={16} className="contract-block-main">
                
                <Col className="gutter-row custom-contract-period-main" span={8} >
                    <span className="label-style-contract">CONTRACT PERIOD</span>
                    <RangePicker className="contract-period-select"
                        placeholder = {["From..","To.."]}
                        onChange={(date, dateString)=>{
                            actions.changeCustomContractModalFields("contractPeriod",dateString)
                        }} 
                    />
                </Col>
                <Col span={6} className="status-main">
                    <label className="label-style">Status</label>
                    <Select 
                        className="status-select"
                        onChange={(e)=>{
                            actions.changeCustomContractModalFields("status",e)
                        }} 
                    >
                    {
                        this.state.status.data.map((opt,idx)=>{
                            return (<Option key={idx} value={opt.value}>{opt.value}</Option>)
                        })
                    }
                    </Select>
                </Col>
                <Col span={3} className="ela-main">
                    <label className="label-style">ELA</label>
                    <Select defaultValue="Yes" 
                        className="ELA-select" 
                        onChange={(e)=>{
                            actions.changeCustomContractModalFields("ela",e.key)
                        }} 
                    >
                        <Option value="Yes">Yes</Option>
                        <Option value="No">No</Option>
                    </Select>

                </Col>
            </Row>
            <Row gutter={16} className="contract-block-row-2">
                <Col className="gutter-row" span={21}>
                    <Input 
                        label={"Opportunity Name *"}
                        floatingLabel={true}
                        onChange={(e)=>{
                                actions.changeCustomContractModalFields("opportunityName",e.target.value)
                        }} 
                    />
                </Col>
                <Col className="gutter-row" span={3}>
                    <Input 
                        label={"Deal Value (USD)"}
                        floatingLabel={true}
                        onChange={(e)=>{
                            actions.changeCustomContractModalFields("dealValue",e.target.value)
                        }} 
                    />
                </Col>
            </Row>
            <Row gutter={16} className="contract-block-row-3">
                <Col className="gutter-row" span={24}>
                    <CustomDropdown 
                        class="custom-dropdown custom-grid-dropdown"
                        title="PRODUCT" 
                        val={this.state.dropdownProduct} 
                        selectedCheckboxes = { this.state.labelsProduct}
                        placeholder="Select Product"
                        onChange={(e,key,val,title) => this.onChangeCheckbox(e,key,val,title)}
                    />  
                </Col>
            </Row>
            <div className="add-custom-contract">
                {
                    this.state.renewalClick ?
                    <div className="scope-body">
                        <Input 
                            label={"Scope of Renewal Opportunity"}
                            floatingLabel={true} 
                            onChange={(e)=>{
                                actions.changeCustomContractModalFields("scopeOfRenewalOpportunity",e.target.value)
                            }}
                        />
                        <div className="delete-icon" onClick={()=>this.setState({renewalClick:false})}>
                            <Icon className="minus-circle" type="minus-circle-o" />
                        </div> 
                    </div>
                    :
                    <button onClick={()=>this.setState({renewalClick:true})}>+ Add Scope of Renewal Opportunity</button>
                }
                
            </div>
        </div> }
        </div> 
        )
    }
}

ContractModalBlock.propTypes = {
    customContactsReducer: PropTypes.object,
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    type:PropTypes.string,
    clickedDetailsData: PropTypes.object,
    index:PropTypes.number
}

export default ContractModalBlock;