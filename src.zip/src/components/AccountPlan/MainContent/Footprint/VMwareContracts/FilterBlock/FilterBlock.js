import React,{Component} from 'react';
import { Slider,Row, Col,DatePicker,Select} from 'antd'; //Input
import './filter-block.scss';
import PropTypes from 'prop-types';
import close from './Close.png';
const { RangePicker } = DatePicker;
const Option = Select.Option;
import CustomDropdown from '../../../../../common/customDropdown/CustomDropdown';
import {CheckboxDataArray,CheckedboxLabelData,ProductsArray } from "../../../../../../Services/CheckboxData";
import {cloneDeep} from 'lodash';

class FilterBlock extends Component{
    state={
        dropdownStage: CheckboxDataArray(ProductsArray(this.props.vmstarReducer.status)),
        dropdownProduct: CheckboxDataArray(ProductsArray(this.props.vmstarReducer.products)),
        labelsStage:[],
        labelsProduct:[],
        contractFrom:"",
        contractTo:"",
        ela:"",
        valueFrom:"",
        valueFrTo:"",
        marks: {
            0: this.props.vmstarReducer.vmstarContracts.minimumValue,
            100:this.props.vmstarReducer.vmstarContracts.maximumValue
        }
    }
    onChangeCheckbox(e,i,val,title){
        let checkedBox = cloneDeep(val);
        checkedBox[i].status = e.target.checked;
        switch(title){
            case "STAGE" :
                        this.setState({ dropdownStage: checkedBox });
                        this.setState({ labelsStage : CheckedboxLabelData(checkedBox)});
                        break;
            case "PRODUCT" :
                        this.setState({ dropdownProduct: checkedBox });
                        this.setState({ labelsProduct : CheckedboxLabelData(checkedBox)});
                        break;
            default:
                        break;
        }
    }
    onChange(date, dateString) {
        this.setState({
            contractFrom: dateString[0],
            contractTo: dateString[1]
        })
    }
    onChangeEla(e){
        this.setState({
            ela: e
        })
    }
    applyFilter(){
        let data;
        data= {
            customerId:"CUST-0002424795" ,
            contractStartDate:this.state.contractFrom ,
            contractEndDate:this.state.contractTo , 
            stage:this.state.labelsStage.toString() , 
            products:this.state.labelsProduct.toString() ,
            ela:this.state.ela,
            valueFrom: this.state.valueFrom ,
            valueTo: this.state.valueTo , 
            limitFrom:1 ,
            limitTo:1000
        }
        this.props.actions.fetchHanaContracts(data);
    }
    render(){
            return(
                    <div>
                        <Row gutter={20} className="filter">
                            <Col span={5} className="contract-period-main" style={{paddingLeft:'0px'}}>
                                <label className="label-style">CONTRACT PERIOD</label>
                                <RangePicker className="contract-period-select"
                                    placeholder = {["From..","To.."]}
                                    onChange={(date,dateString)=> this.onChange(date,dateString)}
                                />
                            </Col>
                            <Col span={6} className="stage-main">
                                <CustomDropdown 
                                    title="STAGE" 
                                    val={this.state.dropdownStage} 
                                    selectedCheckboxes = { this.state.labelsStage}
                                    placeholder="Select Stage"
                                    onChange={(e,key,val,title) => this.onChangeCheckbox(e,key,val,title)}
                                    // onChange={(e,key,val,title)=>{
                                    //     this.props.actions.onChangeCheckbox(e,key,val,title)
                                    // }} 
                                />
                            </Col>
                            <Col span={6} className="product-main">
                                <CustomDropdown 
                                    title="PRODUCT" 
                                    val={this.state.dropdownProduct} 
                                    selectedCheckboxes = { this.state.labelsProduct}
                                    placeholder="Select Product"
                                    onChange={(e,key,val,title) => this.onChangeCheckbox(e,key,val,title)}
                                />  
                            </Col>
                            <Col span={2} className="ela-main">
                                <label className="label-style">ELA</label>
                                <Select placeholder="Select" 
                                    className="ELA-select" 
                                    onChange={(e)=> this.onChangeEla(e)}
                                >
                                    <Option value="Yes">Yes</Option>
                                    <Option value="No">No</Option>
                                </Select>
                            </Col>
                            <Col span={3} className="range-main">
                                <p className="label-style">DEAL RANGE</p>
                                <Slider range marks={this.state.marks} defaultValue={[0,100]} />
                            </Col>
                            <Col span={2} className="close-icon" style={{paddingRight:'0px'}}>
                                <img src={close} onClick = {()=>this.props.handlefilterStatus(false)} />
                            </Col>
                        </Row>
                        <button className="pull-right apply-btn" onClick = {()=>this.applyFilter()}>Apply</button>
                    </div>
                    
            )
        }
}
FilterBlock.propTypes = {
    handlefilterStatus: PropTypes.func,
    vmstarReducer: PropTypes.object,
    actions: PropTypes.object,
}

export default FilterBlock;