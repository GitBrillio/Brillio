import React, { Component } from "react";
import "./profile.scss";
import { getUser } from "../../actions/userActions";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import SocialCast from './socialcast.png'

class Profile extends Component {
  state = { user: {} };
  constructor() {
    super();
  }
  componentWillMount(){
    document.body.style.overflowY = "auto";
  }
  render() {
    if (this.props.userReducer.user) {
      let user = this.props.userReducer.user.data.focusPerson;
      return (
        <div className="Profile-main">
          <div className="profile-header">
            <div className="col-md-4">
              <img className="avatar" src={user.badge_image_url} />
            </div>
            <div className="col-md-8">
              <div className="profile-name11">
                <h2>
                  {user.cn}
                  <span className="nick-name">({user.username})</span>
                </h2>
                <div className="designation">{user.title}</div>
                <a
                  className=""
                  href={user.profile_url}
                  target="_blank"
                >
                  <img className="social-cast" src={SocialCast} />
                </a>
              </div>
            </div>
          </div>

          <div className="contact-info">
            <div className="col-md-4" />
            <div className="col-md-8">
              <div className="contact-infotext">Contact information</div>
              <div className="col-md-4 padding-left0">
                <div className="prifile-label">Email:</div>
                <div className="prifile-add">
                  <a href={"mailto:"+user.email}>
                    {user.email}
                  </a>
                </div>
                <div className="prifile-label">Mobile:</div>
                <div className="prof-info">N/A</div>
                <div className="prifile-label">Company:</div>
                <div className="prof-info">VMware, Inc.</div>
              </div>
              <div className="col-md-8">
                <div className="prifile-label">Skype for Business:</div>
                <div className="prifile-add">
                  <a href={"sip:"+user.email}>
                    {user.email}
                  </a>
                </div>
                <div className="prifile-label">Work Phone:</div>
                <div className="prof-info">N/A</div>
                <div className="prifile-label">Department:</div>
                <div className="prof-info">{user.department}</div>
              </div>
            </div>
          </div>

          {/* <div className="contact-info">
            <div className="col-md-4" />
            <div className="col-md-8">
              <div className="contact-infotext">Contact information</div>
              <div className="col-md-4 padding-left0">
                <div className="prifile-label">Email:</div>
                <div className="prifile-add">{user.email}</div>
                <div className="prifile-label">Mobile:</div>
                <div className="prof-info">N/A</div>
                <div className="prifile-label">Company:</div>
                <div className="prof-info">VMware, Inc.</div>
              </div>
              <div className="col-md-8">
                <div className="prifile-label">Skype for Business:</div>
                <div className="prifile-add">{user.email}</div>
                <div className="prifile-label">Work Phone:</div>
                <div className="prof-info">N/A</div>
                <div className="prifile-label">Department:</div>
                <div className="prof-info">{user.department}</div>
              </div>
            </div>
          </div> */}

          <div className="location-info">
            <div className="col-md-4" />
            <div className="col-md-8">
              <div className="contact-infotext">Location</div>
              <div className="col-md-4 padding-left0">
                <div className="prifile-label">Country:</div>
                <div className="prof-info">{user.country}</div>
                <div className="prifile-label">Workspace:</div>
                <div className="prof-info">N/A</div>
              </div>
              <div className="col-md-8">
                <div className="prifile-label">Office Location:</div>
                <div className="prof-info">{user.location}</div>
                <div className="prifile-label">Workspace Type:</div>
                <div className="prof-info">N/A</div>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      return <div />;
    }
  }
}

const propTypes = {
  getUser: PropTypes.func,
  userReducer: PropTypes.shape({
    user: PropTypes.any
  })
};

Profile.propTypes = propTypes;

const mapStateToProps = (state) => {
  return {
    userReducer: state.user
  };
};
const matchDispatchToProps = (dispatch) => {
  return bindActionCreators(
    {
      getUser
    },
    dispatch
  );
};

export default connect(mapStateToProps, matchDispatchToProps)(Profile);
