import React, { Component } from "react";
import "./MetricCard.scss";
import PropTypes from 'prop-types';


export default class MetricCard extends Component {

  calculateData(data, index, firstKey, secondKey) {
    return data[index].keyName ? data[index][firstKey] : data[index][secondKey];
  }

  firstBox = (data) => {
    return (
      <div className={data.length === 1
        ? `cb1 box1 box-color single-ele ${this.calculateData(data, 0, 'keyName', 'color')}`
        : `box1 box-color cb1 ${this.calculateData(data, 0, 'keyName', 'color')}`
      }>
        <div className="content-holder clearfix">
          <span className="box-no ">{this.calculateData(data, 0, 'keyValue', 'count')}</span>
          <div className="text">
            <span className="display-blk">{this.calculateData(data, 0, 'keyText', 'metric')}</span>
          </div>
        </div>
      </div>
    );
  }

  secondBox = (data) => {
    return (
      <div className={data.length <= 2 ? " right-holder left-text-align" : " right-holder right-text-align"}>
        <div className={data.length === 2
          ? `cb2 box1 box-color ${this.calculateData(data, 1, 'keyName', 'color')}`
          : `cb2 box2 box-color ${this.calculateData(data, 1, 'keyName', 'color')}`
        }>
          <div className="card-holder content-holder">
            <span className="box-no">{this.calculateData(data, 1, 'keyValue', 'count')}</span>
            <div className="text" >
              <span className="display-blk">{this.calculateData(data, 1, 'keyText', 'metric')}</span>
            </div>
          </div>
        </div>
        {data.length === 3 && (
          <div className={`box2 box-color cb3 ${this.calculateData(data, 2, 'keyName', 'color')}`}>
            <div className="card-holder content-holder">
              <span className="box-no">{this.calculateData(data, 2, 'keyValue', 'count')}</span>
              <div className="text">
                <span className="display-blk">
                  {this.calculateData(data, 2, 'keyText', 'metric')}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  emptyBlock() {
    return (
      <div className="empty-block">
        <img src={require(this.props.origin === "looper"
          ? '../../../images/looper_logo.svg'
          : '../../../images/compass_logo.svg')} className="empty-image" />
        <span className="explore-txt">{this.props.origin === "looper"
          ? "Click to explore Looper" : "Click to explore Compass"}</span>
      </div>
    );
  }
  render() {
    let { data } = this.props;
    return (
      <div className="looper-cont">
        <div className="container container-style">
          <div className="header-cont">
            <img
              className="logo"
              src={require(this.props.origin === "looper"
                ? ("../../../images/looper_logo.png")
                : ("../../../images/compass_logo.png"))}
              alt="No image"
            />
            <span className="header-txt">{this.props.origin === "looper" ? "LOOPER" : "COMPASS"}</span>
          </div>
          <div className={`${this.props.origin} body`}>
            {data && data.length > 0 ? (
              <div className="holder">
                {this.firstBox(data)}
                {data.length > 1 && (
                  this.secondBox(data)
                )}
              </div>
            ) : (
                this.emptyBlock()
              )}
          </div>
        </div>
      </div>
    );
  }
}
MetricCard.propTypes = {
  data: PropTypes.array,
  origin: PropTypes.string
};
