import React, { Component } from "react";
import PropTypes from "prop-types";
import Navbar from "./common/Navbar/Navbar.jsx";
export default class RootPage extends Component {
  render() {
    return (
      <div>
        <Navbar />
        {this.props.children}
      </div>
    );
  }
}

RootPage.propTypes = {
  children: PropTypes.node
};
{/*  */}