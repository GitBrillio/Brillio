import React,{ Component } from 'react';
import PropTypes from "prop-types";
import './empty-page.scss';
import EmptyImg from './assets/No Ticket.png';

class EmptyPage extends Component{
    render = () =>{
        return(
            <div className="container-fluid empty-page">
                <div className="center">
                    <img className="img-responsive-alt" src={EmptyImg} alt="Empty Pagae" />
                    <p className="empty-page-desc" dangerouslySetInnerHTML={{__html: this.props.message}}></p>
                    {this.props.actions && this.props.actions.map((opt) => (
                        opt
                    ))}
                </div>
            </div>
        );
    }
}

EmptyPage.propTypes = {
    actions: PropTypes.array,
    message: PropTypes.string
};

export default EmptyPage;
