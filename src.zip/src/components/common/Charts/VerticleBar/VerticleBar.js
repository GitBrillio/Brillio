import React, { Component } from 'react'
import {BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend} from 'recharts';
import PropTypes from 'prop-types';
import _ from 'underscore';

const propTypes = {
    data: PropTypes.array
}

const colors = [
    "#FEB3E7",
    "#59B0FC",
    "#FD7689"
]

class VerticleBar extends Component{

    formatData = (arr) => {
        let finalArr = []
        let groups = _.groupBy(arr,'segmentGrowthLabel');
        Object.keys(groups).map((key,index)=>{
            let ox = {name: key};
            _.each(groups[key],(obj,i)=>{
                ox[obj.fiscalYear] = parseInt(obj.segmentGrowthValue)
            })
            finalArr.push(ox);
        });
        return finalArr;
    }

    formatDataBar = (arr) => {
        let finalArr = []
        
        arr.map((obj,index)=>{
            let ox = {
                name: obj.label,
                segmentGrowth: obj.segmentGrowth
            };
            _.each(obj.segmentGrowth,(obj,i)=>{
                ox[obj.fiscalYear] = parseFloat(obj.segmentGrowthValue)
            })
            finalArr.push(ox);
        });
        return finalArr;
    }

    
    render(){
        const {data} = this.props
        return(
            <section className="verticle-bar">
                <BarChart 
                    width={400} 
                    height={300}
                    margin={{top: 5, right: 10, left: 30, bottom: 15}}
                    data={this.formatDataBar(data)}
                    layout="vertical">
                    <CartesianGrid strokeDasharray="0.5"/>
                    <XAxis 
                        style={{fontSize: 11,fontFamily: "Metropolis"}}
                        type="number"/>
                    <YAxis 
                        style={{fontSize: 13,fontFamily: "Metropolis"}}
                        dataKey="name"
                        type="category" />
                    <Tooltip/>
                    <Legend  iconType="circle" iconSize="10" />
                    {data && data.length > 0 &&
                        data[0].segmentGrowth.map((k,i)=>(
                            <Bar 
                                key={i}
                                dataKey={k.fiscalYear}
                                fill={colors[i]}
                                //radius={[20,20,20,20]}
                            />
                        ))
                    }
                    
                </BarChart>
            </section>
        )
    }
}

VerticleBar.propTypes = propTypes;

export default VerticleBar;
