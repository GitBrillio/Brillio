import React, { Component } from "react";
import { PieChart, Pie, Sector, Cell,Legend, Tooltip} from 'recharts';
import "./PieChrt.scss";
import PropTypes from "prop-types";
import {cloneDeep} from 'lodash';

const propTypes = {
  data: PropTypes.array,
  COLORS: PropTypes.array,
};

export default class PieChrt extends Component {
  formateData = (data) => {
    let cloned = cloneDeep(data);
    let arr = [];
    _.each(cloned,(obj)=>{
        obj.portfolio.portfolioValue = parseFloat(obj.portfolio.portfolioValue);
        arr.push(obj.portfolio)
    });
    return arr;
  }
  render() {
        const RADIAN = Math.PI / 180;                    
        const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }) => {
 	                const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                    const x  = cx + radius * Math.cos(-midAngle * RADIAN);
                    const y = cy  + radius * Math.sin(-midAngle * RADIAN);
 
                    return (
                        <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
                            {`${(percent * 100).toFixed(0)}%`}
                        </text>
                    );
        };
        return (
            <PieChart className="pie-chart-cont" width={500} height={300} onMouseEnter={this.onPieEnter}>
                <Pie
                    data={this.formateData(this.props.data)}
                    cx={220} 
                    cy={105} 
                    labelLine={false}
                    label={renderCustomizedLabel}
                    outerRadius={100} 
                    nameKey="portfolioLabel"
                    dataKey="portfolioValue"
                    fill="#8884d8"
                >
                    {
                        this.props.data.map((entry, index) => <Cell fill={this.props.COLORS[index % this.props.COLORS.length]}/>)
                    }
                </Pie>
                <Tooltip />
                <Legend iconType="circle" iconSize="10" />
            </PieChart>
        );
  }
}

PieChrt.propTypes = propTypes;
