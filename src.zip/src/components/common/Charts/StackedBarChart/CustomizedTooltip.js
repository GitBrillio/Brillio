import React from "react";
import "./CustomizedStack.scss";

const tooltip = (props) =>{
    const {active,payload} = props;
    console.log(active + payload);
    if (active) {
        return (
          <div className="custom-tooltip">
            <p className="labelname">{payload[0].name}</p>
            <p className ="labelvalue">{payload[0].value}</p>
          </div>
        );
      }
  
      return null;
    }

export default tooltip;