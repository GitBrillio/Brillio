import React from "react";
import {KMB} from '../../../../Services/Common';
const label = (props) =>{
    const {x, y, fill, value} = props;
    return <text 
            x={x} 
            y={y} 
            dy={-10} 
            fontSize='14' 
            fontFamily='Metropolis-SemiBold'
            fill={fill}
            textAnchor="middle">{KMB(value.toFixed(2))}</text>
}

export default label;