import React, {Component} from 'react';
import Input from 'muicss/lib/react/input';

export default class InputITAlignment extends Component{
    render = () => {
        const {autoComplete,label,value,onChange,name,type,max,pattern} = this.props
        return(
            <Input
                autoComplete={autoComplete}
                label={label}
                floatingLabel={true}
                value={value}
                onChange={(e)=>{
                    if(typeof pattern !== 'undefined'){
                      let re = new RegExp(pattern);
                      if(re.test(e.target.value)){ // check pattern
                        if(typeof max !== 'undefined'){ // check max
                          if(parseFloat(Math.abs(e.target.value)) <= max){
                            onChange(e);
                          } else { // max fails
                            if(isNaN(parseFloat(e.target.value))){
                              onChange(e);
                            }else{
                              console.log(`It should be less than ${max}`)
                            }
                          }
                        } else{ // RegEx passes
                          this.props.onChange(e);
                        }
                        
                      }else{ // Regex fails
                        console.log("Validation fails!")
                      }
                    } else{ // RegEx not defined
                      onChange(e);
                    }
                }}
                name={name}
                type={type}
            /> 
        )
    }
}