import React,{Component} from 'react';
import './custom-dropdown.scss';
import { Icon } from 'antd';
import Input from 'muicss/lib/react/input';
import PropTypes from 'prop-types';

class CustomDropdown extends Component{
    state={
        showMenu :false
    }
    componentWillMount() {
        window.addEventListener("click", this.handleClickOutside.bind(this));
      }
    
    componentWillUnmount() {
        window.removeEventListener("click", this.handleClickOutside.bind(this));
    }
    handleClickOutside(e) {
        if (
          !e.target.closest(".custom-dropdown")
        ) {
          this.setState({
            showMenu: false,
            dropdownIConRotate: false 
          });
        }
      }

    render(){
        return(
                <div className={this.props.class ? this.props.class : "custom-dropdown"} >
                    <Icon type="down" className={this.state.dropdownIConRotate ? "dropdown-icon dropdown-icon-click" : "dropdown-icon"}  onClick={() => this.setState({ showMenu: !this.state.showMenu, dropdownIConRotate : !this.state.dropdownIConRotate })}/>
                    <Input 
                        className="custom-dropdown-input"
                        label={this.props.title}
                        floatingLabel={true} 
                        placeholder={this.props.placeholder}
                        value={this.props.selectedCheckboxes ? this.props.selectedCheckboxes : this.props.placeholder}
                        onClick={() => this.setState({ showMenu: !this.state.showMenu , dropdownIConRotate : !this.state.dropdownIConRotate})}
                    />
                    {this.state.showMenu &&
                        <div className="menu custom-scroll">
                            {
                                this.props.val && this.props.val.map((value, key) => {
                                    return (
                                        <label className="custom-checkbox-main" key={key}>{value.label}
                                            <input type="checkbox" checked={value.status}
                                                onChange={(e)=>{
                                                    this.props.onChange(e,key,this.props.val,this.props.title);
                                                  }}
                                            />
                                            <span className="custom-checkmark"></span>
                                        </label>
                                    );
                                })
                            }
                        </div>
                    }
                </div>
        )
    }
}
CustomDropdown.propTypes = {
    title : PropTypes.string,
    val:PropTypes.array,
    selectedCheckboxes: PropTypes.array,
    placeholder:PropTypes.string,
    onChange: PropTypes.func,
    class: PropTypes.string
}
export default CustomDropdown;