import React, { Component } from 'react';
import './label-input.scss';
import PropTypes from 'prop-types';

const propTypes = {
    value: PropTypes.any,
    onBlur: PropTypes.func,
    onChange: PropTypes.func,
    className: PropTypes.string
}


class VmLabelInput extends Component{
    state = {
        visible: 'normal'
    }
    render(){
        const {value,onBlur,onChange} = this.props;
        return(
            <section className={"label-input "+this.props.className}>

                { this.state.visible === 'normal' &&
                    <div>
                        <span className="year-info">{value}</span> 
                        <clr-icon onClick={()=>this.setState({visible:'editing'})} shape="pencil" id="edit-icon-403" size="15" class="is-solid"></clr-icon>
                    </div>
                }

                {
                    this.state.visible === 'editing' && 
                    <div>
                        <input onBlur={()=>{
                            this.setState({visible:'normal'})
                            // call up props
                            onBlur()
                            }} 
                            type="text" 
                            value={value}
                            onChange={onChange}
                            placeholder="Please Specify" 
                        />
                    </div>
                }
            </section>
        );
    }
}

export default VmLabelInput