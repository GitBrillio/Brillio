import React, { Component } from "react";
import Search from "../Search/Search.jsx";
import Notification from "../Notification/Notification.jsx";
import "./navbar.scss";

class Navbar extends Component {
  constructor() {
    super();
  }
  render() {
    return (
      <nav className="navbar navbar-default vmware-nav padlr25">
        <div className="navbar-header">
          <button
            type="button"
            className="collapsed navbar-toggle"
            data-toggle="collapse"
            data-target="#bs-example-navbar-collapse-4"
            aria-expanded="false"
          >
            <span className="sr-only">Toggle navigation</span>
            <span className="icon-bar" /> <span className="icon-bar" />
            <span className="icon-bar" />{" "}
          </button>
          <a className="navbar-brand">
            <b>vm</b>ware
          </a>
          <div className="account-tag">GLOBAL ACCOUNTS</div>
        </div>
        <div
          className="collapse navbar-collapse pull-right"
          id="bs-example-navbar-collapse-4"
        >
          <Search />
          <Notification />
        </div>
      </nav>
    );
  }
}

export default Navbar;
