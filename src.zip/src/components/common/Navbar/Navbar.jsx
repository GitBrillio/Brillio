import React, { Component } from "react";
//import Search from "../Search/Search.jsx";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import "./navbar.scss";
import logo from "./logo2X.png";
import UserInfo from "../UserInfo/UserInfo.jsx";
import {PropTypes} from "prop-types";
import { Link } from "react-router-dom";
import Config from '../../../config/Config';
import { getUser,setUserName,getAccess } from "../../../actions/userActions";
import axios from 'axios';
import Cookies from 'universal-cookie';
import moment from 'moment';
import {message} from 'antd';
//import Notification from '../Notification/Notification.jsx';

const cookies = new Cookies();

class Navbar extends Component {
  static propTypes = {
    user: PropTypes.any,
    setUserName: PropTypes.any,
    getUser: PropTypes.any,
    getAccess: PropTypes.func
  };
  constructor() {
    super();
    this.config = new Config();
    let _this = this;
    axios.interceptors.response.use(null, function(err) {
      if(err.response.status === 401) {
        message.error("Session erpired, please login again");
        cookies.set('session_status', 'logged_out', { path: '/' });
        window.location.href = _this.config.oauthUrl;
      }else{
        if(_this.config.env === 'LOCAL' || _this.config.env === 'DEV'){
          message.error(err.response.data.status + '--' + err.response.data.error + "--"+err.response.data.exception);
        } else {
          message.error("Error occured while performing the operation");
        }
      }
      return Promise.reject(err);
    });
  }
  componentWillMount() {
    let session = cookies.get('session_status');
    if (session === undefined || session === 'logged_out' || session === 'expired') {
        cookies.set('session_status', 'in_sso', { path: '/' });
        window.location.href = this.config.oauthUrl
    }
    try{
      let sessionObj = cookies.get('session')
      let currentTime = moment(new Date());
      let sessionExpires = moment(sessionObj.expires_in);
      if(!currentTime.isBefore(sessionExpires) ){
        cookies.remove('session');
        cookies.set('session_status', 'in_sso', { path: '/' });
        window.location.href = this.config.oauthUrl;
      }else{
        this.props.setUserName(sessionObj.username);
        this.props.getUser(sessionObj.username);
        axios.defaults.headers.common['Authorization'] ="Bearer " +sessionObj.access_token;
        this.refreshToken(sessionObj,currentTime);
        /* this.props.getAccess(sessionObj.username); */
      }
    }catch(e){
      //Exception block
    }
  }

  refreshToken(sessionObj,currentTime){
    currentTime = moment(currentTime)
    let sessionExpires = moment(sessionObj.expires_in);
    let duration = moment.duration(sessionExpires.diff(currentTime));
    let diff = 1; //mins
    let hours = duration.asHours() - (diff/60)
    let miliseconds = (hours*60*60)*1000;
    setTimeout(()=>{
        axios({
          url: this.config.ssoUrl.url,
          method: this.config.ssoUrl.method,
          data:{
            codeType: "REFRESH_TOKEN",
            code: sessionObj.refresh_token,
            redirectUrl: this.config.oauth.redirect_uri
          }
        }).then((resp)=>{
          let respObj = resp.data;
          let arr = respObj.access_token.split(".");
          let obj = JSON.parse(atob(arr[1]));
          axios.defaults.headers.common['Authorization'] = "Bearer " + respObj.access_token;
          let date = moment(new Date()).add(respObj.expires_in,"seconds");
          let CookieObj = {
            username:obj.eml,
            loggedIn: true,
            expires_in: date,
            access_token: respObj.access_token,
            refresh_token:respObj.refresh_token,
            id_token: respObj.id_token
          }
          cookies.set('session', JSON.stringify(CookieObj), { path: '/' });
        })
      },miliseconds) //miliseconds
  }
  render() {
    return (
      <header className="header-6">
        <div className="branding branding-logo">
          <Link to="/landing" className="nav-link">
            <img src={logo} />
            <div className="seperator"></div>
            <span className="title nav-logo">Global Accounts</span>
          </Link>
        </div>
        <div className="header-actions">
          {/* <Search /> */}
          {/* <Notification /> */}
          <div className="header-actions-sub">
              <clr-icon size="30" shape="search"></clr-icon>
              <clr-icon size="30" shape="bell"></clr-icon>
          </div>
          <UserInfo />
        </div>
      </header>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    userReducer: state.user
  };
};
const matchDispatchToProps = (dispatch) => {
  return bindActionCreators(
    {
      getUser,
      setUserName,
      getAccess
    },
    dispatch
  );
};

export default connect(mapStateToProps, matchDispatchToProps)(Navbar);
