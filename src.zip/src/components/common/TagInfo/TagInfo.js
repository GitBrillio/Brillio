import React from 'react';
import PropTypes from "prop-types";
import './TagInfo.scss'
import { Switch } from 'antd';

const TagInfo = ({sectionTagTxt,sectionTagChecked,commentTagTxt,commentTagChecked}) => {

    return (
        <div className="taginfo-cont">
           {/* <span className="tag-txt">{sectionTagTxt}</span>
           <Switch defaultChecked={sectionTagChecked}/>
           <span className="-copy"></span>
           <span className="tag-txt">{commentTagTxt}</span>
           <Switch defaultChecked={commentTagChecked}/> */}
        </div>
    );
};

TagInfo.propTypes = {
    tagTxt: PropTypes.string,
    tagChecked:PropTypes.bool
};
export default TagInfo;
