import React, { Component } from "react";
import { Input } from 'antd';
import "./VmTextareaMaterial.scss";
import PropTypes from "prop-types";
const { TextArea } = Input;

const propTypes = {
  placeholder: PropTypes.string,
  title:PropTypes.string,
  onChange: PropTypes.func,
  value: PropTypes.string,
  onBlur: PropTypes.func,
  maxLength: PropTypes.string
};

export default class VmTextareaMaterial extends Component {
  render() {
    return (
            <div className ="textarea-cont-material">
                <div className="textarea-txt">{this.props.title}</div>
                <TextArea 
                    className = "textarea"
                    value={this.props.value}
                    placeholder={this.props.placeholder} 
                    autosize={{ minRows: 4 }} 
                    onChange={(e)=>{
                        this.props.onChange(e);
                    }}
                    onBlur={this.props.onBlur}
                    autosize
                    maxLength={this.props.maxLength}
                />
            </div>
            
    
  
    );
  }
}

VmTextareaMaterial.propTypes = propTypes;
