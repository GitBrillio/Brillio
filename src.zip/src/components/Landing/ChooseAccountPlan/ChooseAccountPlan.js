import React,{ Component } from 'react';
import PropTypes from "prop-types";
import './ChooseAccountPlan.scss';
import AccountPlanBlock from './AccountPlanBlock/AccountPlanBlock'

class ChooseAccountPlan extends Component{
    render = () =>{
        const {plans} = this.props
        return(
            <div>
                {/* <button 
                    className="btn btn-primary create-new-account-plan"
                    onClick = {()=>this.props.handleAccountPlanCreation(true)}
                >
                    + Create New Account Plan
                </button> */}
                <div className="choose-account-plan"> 
                    <div className="choose-header">
                        <span className="text-center choose-header-txt">Choose an account plan</span>
                    </div>
                    <div className="choose-body">
                        <div className="current-plan-txt">Current Plan</div>
                        {
                            plans.map((plan,index)=>{
                                return(
                                    <AccountPlanBlock 
                                        planObj = {plan}
                                        lastUpdated = "24 dec 2018"
                                        progress = {60}
                                        plan = "other" //current
                                        account={this.props.account}
                                    />
                                )
                            })
                        }
                        {/* <div className="other-plan-txt">Other Plans</div>
                        <AccountPlanBlock 
                            planName ="JP Morgen - FY17"
                            lastUpdated = "24 dec 2018"
                            plan = "other"
                        /> */}
                        
                    </div>
                </div>
            </div>
        )
    }
}

ChooseAccountPlan.propTypes = {
    handleAccountPlanCreation: PropTypes.func,
    plans: PropTypes.array
}

export default ChooseAccountPlan;
