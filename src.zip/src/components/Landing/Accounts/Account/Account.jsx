import React, {Component} from 'react';
import './account.scss';
import PropTypes from 'prop-types';
import { Popover,Row,Col,Icon} from 'antd';

class Account extends Component{
    constructor (props) {
        super(props)
        this.state = {
            intialAccountId : '',
            initialAccount: null
        }
    }
    
    getClassName (keyId){
        if(keyId !== 0){
            return "AllaccountCardDefault"
        }else{
            return "AllaccountCardDefaultZero"
        }
    }
    render= () =>{
        const {selected,index,actions,account} = this.props;
        return(
            <div
                onClick={()=>{
                    actions.getAccountDetails(account,index);
                    this.props.selectAccount();
                }} 
                id={this.props.account.accountId} className={"AllaccountCard " + (selected == index ? "AllaccountCardDefault":null)}>
                <div>
                    <div className="Cardpadding">
                                <Popover content={
                                    <div className="pop_over">
                                        <Row>
                                            <Col span={24}>
                                            <p className="pop_over-text">Customer ID</p>
                                            <p className="pop-over-tx">{this.props.account.customerId}</p>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col span={12}>
                                                <div>
                                                    <p className="pop_over-text">City</p>
                                                    <p className="pop-over-tx">{this.props.account.city}</p>
                                                </div>
                                                <div>
                                                    <p className="pop_over-text">Zip</p>
                                                    <p className="pop-over-tx">{this.props.account.zipPostalCode}</p>
                                                </div>
                                            </Col>
                                            <Col span={12}>
                                                <div>
                                                    <p className="pop_over-text">State</p>
                                                    <p className="pop-over-tx">{this.props.account.state}</p>
                                                </div>
                                                <div>
                                                    <p className="pop_over-text">Country</p>
                                                    <p className="pop-over-tx">{this.props.account.country}</p>
                                                </div>
                                            </Col>
                                        </Row>
                                </div>
                            } 
                            placement="right" 
                            trigger="hover">
                                    <div>
                                        <div className="account-name">
                                            {this.props.account.accountName} &nbsp;
                                            {/* <div className="info-icon"></div> */}
                                            <Icon type="info-circle" />
                                        </div>
                                        
                                    </div>
                            </Popover>
                    </div>
                    <span className="content">Account Planned</span>
                    <span className="Points">
                        (0)
                    </span>
                    
                </div>
            </div>
        )
    }
}
Account.propTypes = {
        account: PropTypes.object,
        keyId: PropTypes.number,
        selectAccountFunc: PropTypes.func,
        selected: PropTypes.number
}
export default Account;
