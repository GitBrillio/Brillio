import React, { Component } from "react";
import { Select } from "antd";
import "./VmSelect.scss";
import PropTypes from "prop-types";

const Option = Select.Option;

const propTypes = {
  options: PropTypes.array,
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
  id: PropTypes.string,
  value: PropTypes.string,
  default: PropTypes.string,
  defaultValue: PropTypes.string
};

export default class VmSelect extends Component {
  render() {
    return (
      <div className="vm-select-floating-label">
        <Select
          className="input-select"
          placeholder={this.props.placeholder}
          onChange={(e)=>{
            this.props.onChange(e);
          }}
          value={this.props.value}
        >
          {this.props.options &&
            this.props.options.data &&
            this.props.options.data.map((opt, index) => (
              <Option value={opt} key={index}>
                {opt}
              </Option>
            ))}
        </Select>
        <label>{this.props.placeholder}</label>
      </div>
    );
  }
}

VmSelect.propTypes = propTypes;
