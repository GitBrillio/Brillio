import React from 'react';
import PropTypes from "prop-types";

const SnapTitle = ({ selectedAccount }) => {

    return (
        <div className="snaps col-lg-12 col-md-12 col-sm-12 dashboard-right-text">
            { selectedAccount &&
                <div className="DashboardText">{selectedAccount.accountName}</div>
            }
        </div>
    );
};

SnapTitle.propTypes = {
    selectedAccount: PropTypes.object
};
export default SnapTitle;
