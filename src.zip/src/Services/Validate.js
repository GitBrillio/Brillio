import _ from 'underscore';

export const isDirty = (obj) => {
    let consulate = true;
    Object.keys(obj).map((key)=>{
        if(obj[key] === null || obj[key] === undefined || obj[key] === ''){
            consulate = consulate && false
        }
    });
    return consulate
}

export const validateMax = (arr,key,max) => {
    let sum = _.reduce(arr,(sum,num)=> sum + parseFloat(num.portfolio[key]) , 0);
    if(sum > max){
        return {
            //message: `Percentage exceeds by ${sum-max} it should be ${max}`,
            status: 'GREATER',
            message: 'Total Percentage is more than 100'
        }
    } else if(sum < max){
        return {
            //message: `Percentage value is less than ${Math.abs(sum-max)} it should be ${max}`,
            message: 'Total Percentage is less than 100',
            status: 'SMALLER'
        }
    } else if(isNaN(sum)){
        return {
            message: `Text field Incomplete`,
            status: 'NaN'
        }
    }
    else {
        return {
            message : 'It is equal',
            status: 'EQUAL'
        }
    }
}

export const atleastOne = (arr,key) => {
    let filtered = _.filter(arr,(x)=>{
        return x[key].length > 0
    });
    return filtered.length > 0 ? true : false;
}

export const sumUpGreaterThanZero = (arr,key) => {
    return _.reduce(arr,(sum,val)=>{
        return sum + parseInt(val[key]);
    },0) > 0 ? true : false;
}

export const anyZero = (arr,key) => {
    for(let i = 0; i< arr.length ; i++){
        if(isNaN(arr[i][key]) || arr[i][key] === ""){
            return false;
        }            
    }
    return true
}

export const segmentGrowthValidation = (arr,key) => {
    for(let i = 0; i< arr.length ; i++){
        for(let j = 0; j < arr[i].segmentGrowth.length; j++){
            let obj = arr[i].segmentGrowth[j];
            if(isNaN(obj.segmentGrowthValue) || obj.segmentGrowthValue === "" || obj.segmentGrowthValue == null){
                return false;
            }
        }          
    }
    return true
}