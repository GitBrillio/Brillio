//import {filter,map} from 'lodash';
export const graphLegendData = (data,colors) => {
    let graphArray = [];
    data.map((val,key)=>(
        graphArray.push({
            label :val.name,
            color :colors[key]   
        })
    ))
    return graphArray;
}

export const graphData = (data) => {
    let graphArray = [];
    data.map((val)=>(
        graphArray.push({
            name :val.platformGroup,
            pv : val.totalPriceUsd
        })
    ))
    return graphArray;
}