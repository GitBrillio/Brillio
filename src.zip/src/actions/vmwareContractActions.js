import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import _ from 'underscore';
import {message} from 'antd';
let conf = new Config();


/****************************** Custom Contracts **********************************/

export const getCustomContracts = (accountPlanId) => (dispatch) => {
    axios({
        url: conf.getCustomContracts.url + accountPlanId,
        method: conf.getCustomContracts.method
    }).then(resp=>{
        
        if(resp.status === 200){
             dispatch({
                 type: types.GET_CUSTOM_CONTRACTS,
                 payload: resp.data.data
             });
        }
    })
}
export const fetchHanaContracts = (data,accountPlanId) => (dispatch) => {
    const hide = message.loading("Loading your hana contracts",0)
    axios.post(conf.fetchHanaContracts.url + "/" + accountPlanId + "/contracts/hana" , data)
    .then((resp)=>{
        if(resp.status === 200){
            dispatch({
                type: types.FETCH_HANA_CONTRACTS,
                payload: resp.data.data
            });
        }
        hide();
    })
}
export const searchContracts = (e) => (dispatch) => {
    let input = e.target.value ;
    dispatch({
        type: types.SEARCH_CONTRACTS,
        payload: {input}
    })
}
export const getProducts = () => (dispatch) => {
    axios({
        url: conf.getProducts.url + "/lookup?reference=Product",
        method: conf.getProducts.method
    }).then(resp=>{
        
        if(resp.status === 200){
             dispatch({
                 type: types.FETCH_PRODUCTS,
                 payload: resp.data.data
             });
        }
    })
 }
export const getStatus = () => (dispatch) => {
    axios({
        url: conf.getCustomContractStatus.url + "/lookup?reference=Contract_Stage", 
        method: conf.getCustomContractStatus.method
    }).then(resp=>{
        
        if(resp.status === 200){
             dispatch({
                 type: types.FETCH_STATUS,
                 payload: resp.data.data
             });
        }
    })
}
export const changeCustomContractModalFields= (title, value) => (dispatch) =>{
    dispatch({
        type: types.CHANGE_CUSTOM_CONTRACT_MODAL_FIELDS,
        payload: {title, value}
    })
}
export const updateCustomContracts= (newCustomContracts) => (dispatch) =>{
    dispatch({
        type: types.UPDATE_CUSTOM_CONTRACT,
        payload: newCustomContracts
    });
}
export const changeEditCustomContractModalFields= (title, value) => (dispatch) =>{
    dispatch({
        type: types.CHANGE_EDIT_CUSTOM_CONTRACT_MODAL_FIELDS,
        payload: {title, value}
    })
}
export const resetEditContract = (contract,index) => dispatch =>{
    dispatch({
        type: types.RESET_EDIT_AMBITION,
        payload: {
            index,contract
        }
    })
}
export const submitCustomContract = (values,accountPlanId,modalType) => (dispatch) =>{
    let data;
    if(modalType === "Create"){
        
        data = {
                opportunityName: values.opportunityName,
                accountPlanId: accountPlanId,
                contractFrom: values.contractFrom,
                contractTo: values.contractTo,
                elaFlag: values.elaFlag ? values.elaFlag : "Yes",
                stage: values.stage,
                dealValue: values.dealValue,
                products: values.products,
                opportunityScope: values.opportunityScope
        }
    }
    else{
        data = {
            capCustomContractId: values.capCustomContractId,
            opportunityName: values.opportunityName,
            accountPlanId: accountPlanId,
            contractFrom: values.contractFrom,
            contractTo: values.contractTo,
            elaFlag: values.elaFlag,
            stage: values.stage,
            dealValue: values.dealValue,
            products: values.products,
            opportunityScope: values.opportunityScope
        }
    
    }
    axios.post(conf.submitCustomContract.url + "/contracts/custom" , data)
    .then((resp)=>{
        if(resp.status === 200){
            if(modalType === "Create"){
                dispatch({
                    type: types.PUSH_CUSTOM_CONTRACT,
                    payload: resp.data.data
                });
                message.success('New Contract Created Successfully');
            }
            else{
                message.success('Contract Edited Successfully');
            }
        }else{
            message.error(`Error occures while Creating`);
        }
    })
}
export const DeleteCustomContract = (details,accountPlanId) => (dispatch) =>{
    let data;
        data = {
            opportunityName: details.opportunityName,
            accountPlanId: accountPlanId,
            capCustomContractId: details.capCustomContractId,
            contractFrom: null,
            contractTo: null,
            elaFlag: 1,
            stage: null,
            dealValue: null,
            products: null,
            opportunityScope: null
        }
        let params = {
            method: conf.deleteCustomContract.method,
            url: conf.deleteCustomContract.url,
            data: data
        }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("Contract Deleted Successfully");
        }else{
            message.error('Error occures while deleteing the Contract')
        }
    }) 
}
// export const scopeValueUpdate = (scopeVal,index) => dispatch =>{
//     dispatch({
//         type: types.SCOPE_VAL_UPDATE,
//         payload: {
//             scopeVal,index
//         }
//     })
// }
export const updateVmstarContracts= (newVmstarContracts) => (dispatch) =>{
    dispatch({
        type: types.UPDATE_VMSTAR_CONTRACT,
        payload: newVmstarContracts
    });
}
export const hanascopeUpdate = (data) => dispatch =>{
    //const hide = message.loading("Updating Scope of Renewal Opportunity",0)
    axios.post(conf.updateHanaScope.url, data)
    .then((resp)=>{
        if(resp.status === 200){
            message.success("Scope of Renewal Opportunity Updated Successfully");
            // dispatch({
            //     type: types.SCOPE_VAL_UPDATE,
            //     payload: {
            //         scopeVal,index
            //     }
            // })
        }
        //hide();
    })
}