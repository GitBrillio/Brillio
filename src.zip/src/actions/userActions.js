import * as types from '../constants/actionTypes';
import axios from 'axios';
import Config from '../config/Config';
import { message } from 'antd';
import Cookies from 'universal-cookie';
const cookies = new Cookies();
const conf = new Config();

export const getAccess = (emailId) => (dispatch) => {
  let params = {
    method: conf.getAccess.method,
    url: conf.getAccess.url + emailId
  };
  let sessionObj = cookies.get('session');
  axios.defaults.headers.common['Authorization'] =
    'Bearer ' + sessionObj.access_token;
  axios(params).then((response) => {
    if (response.status === 200) {
      dispatch({
        type: types.SET_ACCESS,
        payload: response.data
      });
    }
  });
};
export function getLooperMetrics(userId) {
  return (dispatch) => {
    let conf = new Config();
    axios({
      ...conf.looperMetrics,
      url: conf.looperMetrics.url + userId
    }).then((response) => {
      if (response.status === 200) {
        dispatch({
          type: types.LOOPER_METRICS_DATA,
          payload: response.data.data
        });
      } else {
        dispatch({});
      }
    });
  };
}
export function getCompassMetrics() {
  let responseConcat = [];
  return (dispatch) => {

    let conf = new Config();
    // First call
    axios({
      ...conf.compassMetrics,
      url: conf.compassMetrics.url  + 'one/metrics/do/read'
    }).then((response) => {
      if(!response.data.empty){
        responseConcat.push(response.data);
      }
      // Second call
      axios({
        ...conf.compassMetrics,
        url: conf.compassMetrics.url  + 'two/metrics/do/read'
      }).then((response1) => {
        if(!response1.data.empty){
          responseConcat.push(response1.data);
        }
        // third call
        axios({
          ...conf.compassMetrics,
          url: conf.compassMetrics.url  + 'three/metrics/do/read'
        }).then((response2) => {
          if(!response2.data.empty){
            responseConcat.push(response2.data);
          }
          dispatch({
            type: types.COMPASS_METRICS_DATA,
            payload: responseConcat
          });
        });
      });
    });
  };
}

export const getWorkstreamForLanding = (emailId, status, dispatch) => {
  let params = {
    method: conf.getAllWorkstreamsForLanding.method,
    url:
      conf.getAllWorkstreamsForLanding.url +
      'email=' +
      emailId +
      '&status=' +
      status
  };
  const hide = message.loading('', 0);
  axios(params).then((response) => {
    hide();
    if (response.status === 200) {
      dispatch({
        type: types.GET_ALL_WORKSTREAMS_FOR_LANDING,
        payload: response.data.workstreams
      });
    }
  });
};

export const getUser = (emailId) => (dispatch) => {
  let params = {
    method: conf.getUser.method,
    url: conf.getUser.url + emailId
  };

  axios(params).then((response) => {
    if (response.status === 200) {
      dispatch({
        type: types.GET_USER,
        payload: response.data
      });
    }
  }).catch(()=>{
    let user = {
      username: emailId,
      data:{
        focusPerson:{
          badge_image_url: null,
          title: null,
          email:emailId,
          department:null,
          country: null,
          location: null,
        }
      }
    };
    dispatch({
      type: types.GET_USER,
      payload: user
    });
  });
};

export const setUserName = (userName) => (dispatch) => {
  dispatch({
    type: types.SET_USERNAME,
    payload: userName
  });
};

export const setPreSearchpath = (path) => (dispatch) => {
  dispatch({
    type: types.SET_PRESEARCH_PATH,
    payload: path
  });
};
