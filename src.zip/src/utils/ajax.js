import axios from 'axios';

const ajax = (param) => {
    return axios(param);
};

export default ajax;
